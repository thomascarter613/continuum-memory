import type {
  ContextRetrievalRequest,
  ContextRetrievalResult,
  CreateContextRetrievalRequest,
  CreateContextRetrievalResult,
  CreateMemoryCandidate,
  CreateMemoryEvent,
  CreateMemoryRecord,
  HandoffCreateRequest,
  HandoffPack,
  MemoryCandidate,
  MemoryCandidatePromotionResult,
  MemoryCandidateSearchRequest,
  MemoryEvent,
  MemoryRecord,
  MemorySearchRequest,
  PromoteMemoryCandidateRequest,
} from "@continuum/domain"

export interface StoreHealth {
  ok: boolean
  kind: "memory" | "postgres"
  details?: Record<string, unknown>
}

export interface ContinuumStore {
  kind: "memory" | "postgres"
  health(): Promise<StoreHealth>
  createEvent(input: CreateMemoryEvent): Promise<MemoryEvent>
  createMemory(input: CreateMemoryRecord): Promise<MemoryRecord>
  getMemory(id: string): Promise<MemoryRecord | null>
  searchMemory(input: MemorySearchRequest): Promise<MemoryRecord[]>
  listActiveMemories(input?: { projectId?: string }): Promise<MemoryRecord[]>
  createContextRetrievalRequest(input: CreateContextRetrievalRequest): Promise<ContextRetrievalRequest>
  createContextRetrievalResult(input: CreateContextRetrievalResult): Promise<ContextRetrievalResult>
  createCandidate(input: CreateMemoryCandidate): Promise<MemoryCandidate>
  getCandidate(id: string): Promise<MemoryCandidate | null>
  searchCandidates(input: MemoryCandidateSearchRequest): Promise<MemoryCandidate[]>
  promoteCandidate(id: string, input: PromoteMemoryCandidateRequest): Promise<MemoryCandidatePromotionResult | null>
  rejectCandidate(id: string, reason: string): Promise<MemoryCandidate | null>
  createHandoff(input: HandoffCreateRequest): Promise<HandoffPack>
  getHandoff(id: string): Promise<HandoffPack | null>
}
