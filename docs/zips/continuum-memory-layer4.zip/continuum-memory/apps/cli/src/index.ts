#!/usr/bin/env bun

import { ContinuumClient } from "@continuum/sdk-js"

const [command, ...args] = process.argv.slice(2)

function help() {
  console.log(`continuum

Commands:
  health                         Check API health
  context-build <task>            Build a basic context pack
  handoff-create <objective>      Create a basic handoff pack
  handoff-compile <objective>     Compile a handoff from durable memory

Environment:
  CONTINUUM_API_URL defaults to http://localhost:3030
`)
}

const client = new ContinuumClient(process.env.CONTINUUM_API_URL ?? "http://localhost:3030")

if (!command || command === "help" || command === "--help" || command === "-h") {
  help()
  process.exit(0)
}

if (command === "health") {
  console.log(JSON.stringify(await client.health(), null, 2))
} else if (command === "context-build") {
  const task = args.join(" ") || "continue current software development task"
  console.log(
    JSON.stringify(
      await client.buildContext({
        task,
        include: ["project_state", "decisions", "procedures", "recent_episodes"],
      }),
      null,
      2,
    ),
  )
} else if (command === "handoff-create") {
  const objective = args.join(" ") || "continue current software development task"
  console.log(
    JSON.stringify(
      await client.createHandoff({
        title: "Continuum Handoff",
        objective,
        currentState: "Initial CLI-generated handoff.",
        nextActions: ["Replace placeholder state with retrieved project memory."],
      }),
      null,
      2,
    ),
  )
} else if (command === "handoff-compile") {
  const objective = args.join(" ") || "continue current software development task"
  console.log(
    JSON.stringify(
      await client.compileHandoff({
        title: "Continuum Compiled Handoff",
        objective,
        retrieval: { strategy: "handoff", minScore: 0.1, includeEvidence: true },
      }),
      null,
      2,
    ),
  )
} else {
  console.error(`Unknown command: ${command}`)
  help()
  process.exit(1)
}
