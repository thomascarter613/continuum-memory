import type {
  ContextBuildRequest,
  CreateMemoryCandidate,
  CreateMemoryEvent,
  CreateMemoryRecord,
  ExtractMemoryCandidatesRequest,
  HandoffCompileRequest,
  HandoffCreateRequest,
  MemoryCandidateSearchRequest,
  MemorySearchRequest,
  PromoteMemoryCandidateRequest,
  RejectMemoryCandidateRequest,
} from "@continuum/domain"

export class ContinuumClient {
  constructor(private readonly baseUrl = "http://localhost:3030") {}

  async health() {
    return this.get("/healthz")
  }

  async createEvent(input: CreateMemoryEvent) {
    return this.post("/v1/events", input)
  }

  async createMemory(input: CreateMemoryRecord) {
    return this.post("/v1/memory", input)
  }

  async getMemory(id: string) {
    return this.get(`/v1/memory/${id}`)
  }

  async searchMemory(input: MemorySearchRequest) {
    return this.post("/v1/memory/search", input)
  }

  async createCandidate(input: CreateMemoryCandidate) {
    return this.post("/v1/memory/candidates", input)
  }

  async extractCandidates(input: ExtractMemoryCandidatesRequest) {
    return this.post("/v1/memory/candidates/extract", input)
  }

  async searchCandidates(input: MemoryCandidateSearchRequest) {
    return this.post("/v1/memory/candidates/search", input)
  }

  async getCandidate(id: string) {
    return this.get(`/v1/memory/candidates/${id}`)
  }

  async promoteCandidate(id: string, input: PromoteMemoryCandidateRequest) {
    return this.post(`/v1/memory/candidates/${id}/promote`, input)
  }

  async rejectCandidate(id: string, input: RejectMemoryCandidateRequest) {
    return this.post(`/v1/memory/candidates/${id}/reject`, input)
  }

  async planContext(input: ContextBuildRequest) {
    return this.post("/v1/context/plan", input)
  }

  async buildContext(input: ContextBuildRequest) {
    return this.post("/v1/context/build", input)
  }

  async createHandoff(input: HandoffCreateRequest) {
    return this.post("/v1/handoffs", input)
  }

  async compileHandoff(input: HandoffCompileRequest) {
    return this.post("/v1/handoffs/compile", input)
  }

  async getHandoff(id: string) {
    return this.get(`/v1/handoffs/${id}`)
  }

  private async get(path: string) {
    const response = await fetch(`${this.baseUrl}${path}`)
    if (!response.ok) throw new Error(`Continuum GET ${path} failed: ${response.status}`)
    return response.json()
  }

  private async post(path: string, body: unknown) {
    const response = await fetch(`${this.baseUrl}${path}`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body),
    })
    if (!response.ok) {
      const text = await response.text()
      throw new Error(`Continuum POST ${path} failed: ${response.status} ${text}`)
    }
    return response.json()
  }
}
