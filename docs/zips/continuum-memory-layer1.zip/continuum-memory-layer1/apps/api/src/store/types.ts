import type {
  ContextBuildRequest,
  CreateMemoryEvent,
  CreateMemoryRecord,
  HandoffCreateRequest,
  HandoffPack,
  MemoryEvent,
  MemoryRecord,
  MemorySearchRequest,
} from "@continuum/domain"

export interface StoreHealth {
  ok: boolean
  kind: "memory" | "postgres"
  details?: Record<string, unknown>
}

export interface ContinuumStore {
  kind: "memory" | "postgres"
  health(): Promise<StoreHealth>
  createEvent(input: CreateMemoryEvent): Promise<MemoryEvent>
  createMemory(input: CreateMemoryRecord): Promise<MemoryRecord>
  getMemory(id: string): Promise<MemoryRecord | null>
  searchMemory(input: MemorySearchRequest): Promise<MemoryRecord[]>
  listActiveMemories(input?: Pick<ContextBuildRequest, "projectId">): Promise<MemoryRecord[]>
  createHandoff(input: HandoffCreateRequest): Promise<HandoffPack>
  getHandoff(id: string): Promise<HandoffPack | null>
}
