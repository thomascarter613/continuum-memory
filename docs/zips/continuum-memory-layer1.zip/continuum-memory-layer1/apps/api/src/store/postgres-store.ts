import { randomUUID } from "node:crypto"
import type {
  CreateMemoryEvent,
  CreateMemoryRecord,
  HandoffCreateRequest,
  HandoffPack,
  MemoryEvent,
  MemoryRecord,
  MemorySearchRequest,
} from "@continuum/domain"
import type { PgPool } from "../db/pool"
import { renderHandoffMarkdown } from "../lib/handoff-markdown"
import { now } from "../lib/time"
import { eventFromRow, handoffFromRow, memoryFromRow } from "./postgres-mappers"
import type { ContinuumStore, StoreHealth } from "./types"

export class PostgresContinuumStore implements ContinuumStore {
  readonly kind = "postgres" as const

  constructor(private readonly pool: PgPool) {}

  async health(): Promise<StoreHealth> {
    const result = await this.pool.query<{
      events: string
      memories: string
      handoffs: string
    }>(`select
        (select count(*) from memory_events)::text as events,
        (select count(*) from memory_records)::text as memories,
        (select count(*) from handoff_packs)::text as handoffs`)

    return {
      ok: true,
      kind: this.kind,
      details: {
        events: Number(result.rows[0]?.events ?? 0),
        memories: Number(result.rows[0]?.memories ?? 0),
        handoffs: Number(result.rows[0]?.handoffs ?? 0),
      },
    }
  }

  async createEvent(input: CreateMemoryEvent): Promise<MemoryEvent> {
    const event: MemoryEvent = {
      ...input,
      id: input.id ?? randomUUID(),
      occurredAt: input.occurredAt ?? now(),
      payload: input.payload ?? {},
    }

    const result = await this.pool.query(
      `insert into memory_events (
        id, event_type, actor_type, actor_id, subject_type, subject_id,
        project_id, conversation_id, session_id, run_id, payload,
        occurred_at, causation_id, correlation_id
      ) values (
        $1, $2, $3, $4, $5, $6,
        $7, $8, $9, $10, $11::jsonb,
        $12::timestamptz, $13, $14
      ) returning *`,
      [
        event.id,
        event.eventType,
        event.actorType,
        event.actorId ?? null,
        event.subjectType ?? null,
        event.subjectId ?? null,
        event.projectId ?? null,
        event.conversationId ?? null,
        event.sessionId ?? null,
        event.runId ?? null,
        JSON.stringify(event.payload ?? {}),
        event.occurredAt,
        event.causationId ?? null,
        event.correlationId ?? null,
      ],
    )

    const row = result.rows[0]
    if (!row) throw new Error("Failed to insert memory event")
    return eventFromRow(row)
  }

  async createMemory(input: CreateMemoryRecord): Promise<MemoryRecord> {
    const timestamp = now()
    const memory: MemoryRecord = {
      ...input,
      id: input.id ?? randomUUID(),
      sourceEventIds: input.sourceEventIds ?? [],
      sourceArtifactIds: input.sourceArtifactIds ?? [],
      scope: input.scope ?? {},
      confidence: input.confidence ?? 0.5,
      sensitivity: input.sensitivity ?? "normal",
      status: input.status ?? "active",
      createdAt: input.createdAt ?? timestamp,
      updatedAt: input.updatedAt ?? timestamp,
    }

    const client = await this.pool.connect()
    try {
      await client.query("begin")
      const result = await client.query(
        `insert into memory_records (
          id, memory_type, namespace, scope, content, structured_content,
          source_event_ids, source_artifact_ids, confidence, sensitivity, status,
          valid_from, valid_to, supersedes, superseded_by, created_at, updated_at
        ) values (
          $1, $2, $3, $4::jsonb, $5, $6::jsonb,
          $7::uuid[], $8::uuid[], $9, $10, $11,
          $12::timestamptz, $13::timestamptz, $14, $15, $16::timestamptz, $17::timestamptz
        ) returning *`,
        [
          memory.id,
          memory.memoryType,
          memory.namespace,
          JSON.stringify(memory.scope),
          memory.content,
          memory.structuredContent ? JSON.stringify(memory.structuredContent) : null,
          memory.sourceEventIds,
          memory.sourceArtifactIds,
          memory.confidence,
          memory.sensitivity,
          memory.status,
          memory.validFrom ?? null,
          memory.validTo ?? null,
          memory.supersedes ?? null,
          memory.supersededBy ?? null,
          memory.createdAt,
          memory.updatedAt,
        ],
      )

      if (memory.supersedes) {
        await client.query(
          `update memory_records
           set status = 'superseded', superseded_by = $1, updated_at = now()
           where id = $2 and status <> 'forgotten'`,
          [memory.id, memory.supersedes],
        )
      }

      await client.query("commit")
      const row = result.rows[0]
      if (!row) throw new Error("Failed to insert memory record")
      return memoryFromRow(row)
    } catch (error) {
      await client.query("rollback")
      throw error
    } finally {
      client.release()
    }
  }

  async getMemory(id: string): Promise<MemoryRecord | null> {
    const result = await this.pool.query(`select * from memory_records where id = $1`, [id])
    const row = result.rows[0]
    if (!row) return null
    return memoryFromRow(row)
  }

  async searchMemory(input: MemorySearchRequest): Promise<MemoryRecord[]> {
    const where: string[] = []
    const params: unknown[] = []

    if (!input.includeSuperseded) {
      params.push("superseded")
      where.push(`status <> $${params.length}`)
    }

    if (input.namespace) {
      params.push(input.namespace)
      where.push(`namespace = $${params.length}`)
    }

    if (input.memoryTypes?.length) {
      params.push(input.memoryTypes)
      where.push(`memory_type = any($${params.length}::text[])`)
    }

    if (input.projectId) {
      params.push(JSON.stringify({ projectId: input.projectId }))
      const scopeParam = params.length
      params.push(`%${input.projectId}%`)
      const namespaceParam = params.length
      where.push(`(scope @> $${scopeParam}::jsonb or namespace ilike $${namespaceParam})`)
    }

    if (input.query) {
      params.push(`%${input.query}%`)
      where.push(`content ilike $${params.length}`)
    }

    params.push(input.limit ?? 20)
    const limitParam = params.length
    const sql = `select * from memory_records
      ${where.length ? `where ${where.join(" and ")}` : ""}
      order by updated_at desc
      limit $${limitParam}`

    const result = await this.pool.query(sql, params)
    return result.rows.map(memoryFromRow)
  }

  async listActiveMemories(input?: { projectId?: string }): Promise<MemoryRecord[]> {
    const params: unknown[] = ["active"]
    const where = [`status = $1`]

    if (input?.projectId) {
      params.push(JSON.stringify({ projectId: input.projectId }))
      const scopeParam = params.length
      params.push(`%${input.projectId}%`)
      const namespaceParam = params.length
      where.push(`(scope @> $${scopeParam}::jsonb or namespace ilike $${namespaceParam})`)
    }

    const result = await this.pool.query(`select * from memory_records where ${where.join(" and ")} order by updated_at desc`, params)
    return result.rows.map(memoryFromRow)
  }

  async createHandoff(input: HandoffCreateRequest): Promise<HandoffPack> {
    const pack: HandoffPack = {
      id: randomUUID(),
      ...(input.projectId ? { projectId: input.projectId } : {}),
      title: input.title ?? "Continuum Handoff",
      objective: input.objective,
      markdown: renderHandoffMarkdown({
        title: input.title ?? "Continuum Handoff",
        objective: input.objective,
        currentState: input.currentState ?? "",
        acceptedDecisions: input.acceptedDecisions ?? [],
        openQuestions: input.openQuestions ?? [],
        nextActions: input.nextActions ?? [],
        artifactRefs: input.artifactRefs ?? [],
      }),
      payload: {
        title: input.title ?? "Continuum Handoff",
        objective: input.objective,
        currentState: input.currentState ?? "",
        acceptedDecisions: input.acceptedDecisions ?? [],
        openQuestions: input.openQuestions ?? [],
        nextActions: input.nextActions ?? [],
        artifactRefs: input.artifactRefs ?? [],
        ...(input.projectId ? { projectId: input.projectId } : {}),
      },
      createdAt: now(),
    }

    const result = await this.pool.query(
      `insert into handoff_packs (id, project_id, title, objective, markdown, payload, created_at)
       values ($1, $2, $3, $4, $5, $6::jsonb, $7::timestamptz)
       returning *`,
      [
        pack.id,
        pack.projectId ?? null,
        pack.title,
        pack.objective,
        pack.markdown,
        JSON.stringify(pack.payload),
        pack.createdAt,
      ],
    )

    const row = result.rows[0]
    if (!row) throw new Error("Failed to insert handoff pack")
    return handoffFromRow(row)
  }

  async getHandoff(id: string): Promise<HandoffPack | null> {
    const result = await this.pool.query(`select * from handoff_packs where id = $1`, [id])
    const row = result.rows[0]
    if (!row) return null
    return handoffFromRow(row)
  }
}
