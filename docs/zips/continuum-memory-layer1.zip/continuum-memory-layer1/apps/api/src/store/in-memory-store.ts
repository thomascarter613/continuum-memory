import { randomUUID } from "node:crypto"
import type {
  CreateMemoryEvent,
  CreateMemoryRecord,
  HandoffCreateRequest,
  HandoffPack,
  MemoryEvent,
  MemoryRecord,
  MemorySearchRequest,
} from "@continuum/domain"
import { renderHandoffMarkdown } from "../lib/handoff-markdown"
import { now } from "../lib/time"
import type { ContinuumStore, StoreHealth } from "./types"

export class InMemoryContinuumStore implements ContinuumStore {
  readonly kind = "memory" as const

  private readonly events = new Map<string, MemoryEvent>()
  private readonly memories = new Map<string, MemoryRecord>()
  private readonly handoffs = new Map<string, HandoffPack>()

  async health(): Promise<StoreHealth> {
    return {
      ok: true,
      kind: this.kind,
      details: {
        events: this.events.size,
        memories: this.memories.size,
        handoffs: this.handoffs.size,
      },
    }
  }

  async createEvent(input: CreateMemoryEvent): Promise<MemoryEvent> {
    const event: MemoryEvent = {
      ...input,
      id: input.id ?? randomUUID(),
      occurredAt: input.occurredAt ?? now(),
      payload: input.payload ?? {},
    }
    this.events.set(event.id, event)
    return event
  }

  async createMemory(input: CreateMemoryRecord): Promise<MemoryRecord> {
    const timestamp = now()
    const memory: MemoryRecord = {
      ...input,
      id: input.id ?? randomUUID(),
      sourceEventIds: input.sourceEventIds ?? [],
      sourceArtifactIds: input.sourceArtifactIds ?? [],
      scope: input.scope ?? {},
      confidence: input.confidence ?? 0.5,
      sensitivity: input.sensitivity ?? "normal",
      status: input.status ?? "active",
      createdAt: input.createdAt ?? timestamp,
      updatedAt: input.updatedAt ?? timestamp,
    }
    this.memories.set(memory.id, memory)
    return memory
  }

  async getMemory(id: string): Promise<MemoryRecord | null> {
    return this.memories.get(id) ?? null
  }

  async searchMemory(input: MemorySearchRequest): Promise<MemoryRecord[]> {
    const query = input.query?.toLowerCase()
    return [...this.memories.values()]
      .filter((memory) => input.includeSuperseded || memory.status !== "superseded")
      .filter((memory) => !input.namespace || memory.namespace === input.namespace)
      .filter((memory) => !input.memoryTypes || input.memoryTypes.includes(memory.memoryType))
      .filter((memory) => !input.projectId || memory.scope.projectId === input.projectId || memory.namespace.includes(input.projectId))
      .filter((memory) => !query || memory.content.toLowerCase().includes(query))
      .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt))
      .slice(0, input.limit ?? 20)
  }

  async listActiveMemories(input?: { projectId?: string }): Promise<MemoryRecord[]> {
    return [...this.memories.values()]
      .filter((memory) => memory.status === "active")
      .filter((memory) => !input?.projectId || memory.scope.projectId === input.projectId || memory.namespace.includes(input.projectId))
      .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt))
  }

  async createHandoff(input: HandoffCreateRequest): Promise<HandoffPack> {
    const pack: HandoffPack = {
      id: randomUUID(),
      ...(input.projectId ? { projectId: input.projectId } : {}),
      title: input.title ?? "Continuum Handoff",
      objective: input.objective,
      markdown: renderHandoffMarkdown({
        title: input.title ?? "Continuum Handoff",
        objective: input.objective,
        currentState: input.currentState ?? "",
        acceptedDecisions: input.acceptedDecisions ?? [],
        openQuestions: input.openQuestions ?? [],
        nextActions: input.nextActions ?? [],
        artifactRefs: input.artifactRefs ?? [],
      }),
      payload: {
        title: input.title ?? "Continuum Handoff",
        objective: input.objective,
        currentState: input.currentState ?? "",
        acceptedDecisions: input.acceptedDecisions ?? [],
        openQuestions: input.openQuestions ?? [],
        nextActions: input.nextActions ?? [],
        artifactRefs: input.artifactRefs ?? [],
        ...(input.projectId ? { projectId: input.projectId } : {}),
      },
      createdAt: now(),
    }
    this.handoffs.set(pack.id, pack)
    return pack
  }

  async getHandoff(id: string): Promise<HandoffPack | null> {
    return this.handoffs.get(id) ?? null
  }
}
