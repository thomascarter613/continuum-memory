import { describe, expect, test } from "bun:test"
import { InMemoryContinuumStore } from "../in-memory-store"

describe("InMemoryContinuumStore", () => {
  test("creates and retrieves a memory record", async () => {
    const store = new InMemoryContinuumStore()
    const created = await store.createMemory({
      memoryType: "semantic",
      namespace: "project:test",
      content: "The test project uses durable memory.",
      scope: { projectId: "test" },
    })

    const found = await store.getMemory(created.id)
    expect(found?.content).toBe("The test project uses durable memory.")
  })

  test("searches active non-superseded memories", async () => {
    const store = new InMemoryContinuumStore()
    await store.createMemory({
      memoryType: "semantic",
      namespace: "project:test",
      content: "Use PostgreSQL as canonical memory store.",
      scope: { projectId: "test" },
    })
    await store.createMemory({
      memoryType: "semantic",
      namespace: "project:test",
      content: "Old vector-only design.",
      scope: { projectId: "test" },
      status: "superseded",
    })

    const results = await store.searchMemory({ query: "store", limit: 10, includeSuperseded: false })
    expect(results).toHaveLength(1)
    expect(results[0]?.content).toContain("PostgreSQL")
  })
})
