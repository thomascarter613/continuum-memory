import { randomUUID } from "node:crypto"
import { Hono } from "hono"
import { ZodError } from "zod"
import {
  ContextBuildRequestSchema,
  CreateMemoryEventSchema,
  CreateMemoryRecordSchema,
  HandoffCreateRequestSchema,
  MemorySearchRequestSchema,
  type ContextPack,
  type MemoryRecord,
} from "@continuum/domain"
import { getConfig } from "./config"
import { estimateTokens, now } from "./lib/time"
import { createStore, type ContinuumStore } from "./store"

const config = getConfig()
const store = createStore(config)
const app = createApp(store)

function memoriesForSection(sectionName: string, activeMemories: MemoryRecord[]) {
  return activeMemories.filter((memory) => {
    if (sectionName === "decisions") return memory.memoryType === "decision"
    if (sectionName === "procedures") return memory.memoryType === "procedural"
    if (sectionName === "recent_episodes") return memory.memoryType === "episodic"
    if (sectionName === "user_preferences") return memory.namespace.includes("user") || memory.scope.kind === "user_preference"
    if (sectionName === "project_state") return memory.namespace.includes("project") || memory.scope.kind === "project_state"
    if (sectionName === "open_tasks") return memory.scope.kind === "open_task" || memory.content.toLowerCase().includes("open task")
    return true
  })
}

export function createApp(activeStore: ContinuumStore) {
  const api = new Hono()

  api.onError((error, c) => {
    if (error instanceof ZodError) {
      return c.json({ error: "invalid_request", issues: error.issues }, 400)
    }

    console.error(error)
    return c.json(
      {
        error: "internal_error",
        message: error instanceof Error ? error.message : "Unknown error",
      },
      500,
    )
  })

  api.get("/healthz", async (c) => {
    try {
      const health = await activeStore.health()
      return c.json({ ok: health.ok, service: "continuum-memory-api", store: health })
    } catch (error) {
      return c.json(
        {
          ok: false,
          service: "continuum-memory-api",
          store: {
            ok: false,
            kind: activeStore.kind,
            message: error instanceof Error ? error.message : "Store health check failed",
          },
        },
        503,
      )
    }
  })

  api.post("/v1/events", async (c) => {
    const body = await c.req.json()
    const parsed = CreateMemoryEventSchema.parse(body)
    const event = await activeStore.createEvent(parsed)
    return c.json(event, 201)
  })

  api.post("/v1/memory", async (c) => {
    const body = await c.req.json()
    const parsed = CreateMemoryRecordSchema.parse(body)
    const memory = await activeStore.createMemory(parsed)
    return c.json(memory, 201)
  })

  api.get("/v1/memory/:id", async (c) => {
    const memory = await activeStore.getMemory(c.req.param("id"))
    if (!memory) {
      return c.json({ error: "memory_not_found" }, 404)
    }
    return c.json(memory)
  })

  api.post("/v1/memory/search", async (c) => {
    const body = await c.req.json()
    const parsed = MemorySearchRequestSchema.parse(body)
    const results = await activeStore.searchMemory(parsed)
    return c.json({ results })
  })

  api.post("/v1/context/build", async (c) => {
    const body = await c.req.json()
    const parsed = ContextBuildRequestSchema.parse(body)
    const activeMemories = await activeStore.listActiveMemories({ projectId: parsed.projectId })

    const sections = parsed.include.map((sectionName) => {
      const sectionMemories = memoriesForSection(sectionName, activeMemories)
      const content = sectionMemories.map((memory) => `- ${memory.content}`).join("\n")
      return {
        name: sectionName,
        purpose: `Context section for ${sectionName}`,
        memories: sectionMemories,
        content,
      }
    })

    const assembled = sections.map((section) => `## ${section.name}\n${section.content}`).join("\n\n")
    const contextPack: ContextPack = {
      id: randomUUID(),
      projectId: parsed.projectId,
      task: parsed.task,
      sections,
      tokenBudget: {
        maxInputTokens: parsed.budget.maxInputTokens,
        estimatedUsedTokens: estimateTokens(assembled),
      },
      createdAt: now(),
    }

    return c.json(contextPack)
  })

  api.post("/v1/handoffs", async (c) => {
    const body = await c.req.json()
    const parsed = HandoffCreateRequestSchema.parse(body)
    const pack = await activeStore.createHandoff(parsed)
    return c.json(pack, 201)
  })

  api.get("/v1/handoffs/:id", async (c) => {
    const handoff = await activeStore.getHandoff(c.req.param("id"))
    if (!handoff) {
      return c.json({ error: "handoff_not_found" }, 404)
    }
    return c.json(handoff)
  })

  return api
}

export default {
  port: config.apiPort,
  fetch: app.fetch,
}

console.log(`continuum-memory-api listening on http://localhost:${config.apiPort} with ${store.kind} store`)
