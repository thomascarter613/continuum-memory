# Continuum Memory

Continuum Memory is a model-agnostic persistent memory and context control plane for software-development agents and LLM-assisted work.

It is designed around this rule:

> Chats are disposable. Memory is durable. Context is assembled. Handoffs are explicit artifacts.

This repository is the reusable memory system itself. Product/application monorepos should not embed this whole system. Instead, product repos should include a thin `.memory/` adapter, `AGENTS.md`, ADRs, work packets, current-state docs, and handoff files.

## Layer 1 status

Layer 1 adds the first durable backend.

Included now:

- Bun workspace
- TypeScript packages
- Hono API
- shared domain schemas
- JavaScript SDK shell
- CLI shell
- PostgreSQL-backed storage repositories
- in-memory storage implementation for tests/dev
- migration runner
- SQL migrations for events, memory records, semantic facts, and handoff packs
- Docker Compose for Postgres/pgvector, Qdrant, Valkey, and MinIO
- smoke-test script for the API
- memory taxonomy docs
- ADRs
- work planning docs
- OPA/Rego policy stubs
- prompt templates
- project-adapter template for other monorepos

Still intentionally deferred to later layers:

- LLM-based memory candidate extraction
- pgvector embedding writes and semantic retrieval
- Qdrant synchronization
- policy enforcement runtime
- artifact/blob indexing
- temporal knowledge graph
- admin UI

## Quickstart with durable PostgreSQL storage

```bash
cp .env.example .env
bun install
bun run infra:up
bun run db:migrate
bun run dev
```

In another terminal:

```bash
curl http://localhost:3030/healthz
```

Expected shape:

```json
{
  "ok": true,
  "service": "continuum-memory-api",
  "store": {
    "ok": true,
    "kind": "postgres"
  }
}
```

Run the smoke test:

```bash
bun run smoke:api
```

The smoke test creates a memory event, writes a decision memory, searches memory, builds a context pack, and creates a handoff pack.

## Quickstart with process-local in-memory storage

Use this only for throwaway development or tests:

```bash
cp .env.example .env
printf '\nCONTINUUM_STORE=memory\n' >> .env
bun install
bun run dev
```

The in-memory store is useful for API shape testing, but it does not survive process restarts.

## Recommended workspace layout

```txt
Workspace/
├── continuum-memory/       # this reusable memory system
├── your-product-monorepo/  # product repo using a thin .memory adapter
└── .continuum-data/        # local runtime data, not committed
```

## Apply the project adapter to another repo

From this repository:

```bash
./scripts/create-project-adapter.sh ../your-product-monorepo
```

This copies the template files that let Continuum understand a software project.

## Main concepts

- **Working memory**: current run/session/task state.
- **Episodic memory**: what happened, when, and with what evidence.
- **Semantic memory**: durable facts, preferences, project state, and stable knowledge.
- **Procedural memory**: reusable workflows, runbooks, prompts, and executable skills.
- **Decision memory**: ADR-like decision records with rationale and alternatives.
- **Artifact memory**: files, generated outputs, logs, diagrams, and external documents.
- **Handoff memory**: portable state packages for resuming work in new chats or models.

## Development commands

```bash
bun run infra:up
bun run db:migrate
bun run dev
bun run smoke:api
bun run format
bun run lint
bun run typecheck
bun run test
bun run check
```

## API endpoints

```txt
GET  /healthz
POST /v1/events
POST /v1/memory
GET  /v1/memory/:id
POST /v1/memory/search
POST /v1/context/build
POST /v1/handoffs
GET  /v1/handoffs/:id
```

## Storage contract

The API depends on a storage interface, not a concrete database implementation. Current implementations:

```txt
apps/api/src/store/in-memory-store.ts
apps/api/src/store/postgres-store.ts
```

Use PostgreSQL for real work:

```env
CONTINUUM_STORE=postgres
CONTINUUM_DATABASE_URL=postgres://continuum:continuum@localhost:5432/continuum
```

Use memory only for throwaway tests:

```env
CONTINUUM_STORE=memory
```
