#!/usr/bin/env bash
set -euo pipefail

BASE_URL="${CONTINUUM_API_URL:-http://localhost:3030}"
EVENT_ID="$(bun -e 'console.log(crypto.randomUUID())')"
MEMORY_ID="$(bun -e 'console.log(crypto.randomUUID())')"

echo "Checking health..."
curl -fsS "$BASE_URL/healthz"
echo

echo "Creating event $EVENT_ID..."
curl -fsS -X POST "$BASE_URL/v1/events" \
  -H 'content-type: application/json' \
  -d "{
    \"id\":\"$EVENT_ID\",
    \"eventType\":\"message.received\",
    \"actorType\":\"user\",
    \"actorId\":\"local-dev\",
    \"projectId\":\"demo\",
    \"payload\":{\"text\":\"Use PostgreSQL as canonical memory store.\"}
  }"
echo

echo "Creating memory $MEMORY_ID..."
curl -fsS -X POST "$BASE_URL/v1/memory" \
  -H 'content-type: application/json' \
  -d "{
    \"id\":\"$MEMORY_ID\",
    \"memoryType\":\"decision\",
    \"namespace\":\"project:demo/decisions\",
    \"scope\":{\"projectId\":\"demo\"},
    \"content\":\"Use PostgreSQL as the canonical memory store and treat vector stores as indexes.\",
    \"sourceEventIds\":[\"$EVENT_ID\"],
    \"confidence\":0.95
  }"
echo

echo "Reading memory $MEMORY_ID..."
curl -fsS "$BASE_URL/v1/memory/$MEMORY_ID"
echo

echo "Searching memory..."
curl -fsS -X POST "$BASE_URL/v1/memory/search" \
  -H 'content-type: application/json' \
  -d '{"projectId":"demo","query":"PostgreSQL","limit":10}'
echo

echo "Building context..."
curl -fsS -X POST "$BASE_URL/v1/context/build" \
  -H 'content-type: application/json' \
  -d '{"projectId":"demo","task":"continue architecture implementation","include":["decisions","project_state"]}'
echo

echo "Creating handoff..."
curl -fsS -X POST "$BASE_URL/v1/handoffs" \
  -H 'content-type: application/json' \
  -d '{
    "projectId":"demo",
    "title":"Demo Handoff",
    "objective":"Resume durable memory implementation.",
    "currentState":"Layer 1 durable store has been added.",
    "acceptedDecisions":["Use PostgreSQL as canonical store."],
    "nextActions":["Add memory candidate extraction pipeline."]
  }'
echo
