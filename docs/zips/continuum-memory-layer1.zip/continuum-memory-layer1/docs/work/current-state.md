# Current State

## Active Objective

Build Continuum Memory: a model-agnostic persistent memory and context control plane for software-development assistance.

## Current Phase

Layer 1 durable store scaffold is complete. The system is ready for Layer 2 memory ingestion.

## Accepted Decisions

- Build Continuum Memory as a separate reusable monorepo.
- Use repo-local `.memory/` adapters in product monorepos.
- Use PostgreSQL as canonical memory store.
- Treat vector stores as indexes, not source of truth.
- Make handoff packs first-class artifacts.
- Use a storage interface so the API is not coupled to one persistence implementation.
- Keep in-memory storage only for tests and throwaway development.

## Layer 1 Completed

- Added `ContinuumStore` interface.
- Added `InMemoryContinuumStore`.
- Added `PostgresContinuumStore`.
- Added PostgreSQL pool and migration runner.
- Added durable persistence for `memory_events`, `memory_records`, and `handoff_packs`.
- Added supersession update behavior when a new memory supersedes an old memory.
- Added smoke-test script.
- Added durable-store ADR and work packet.

## Next Recommended Layer

Layer 2 should implement the memory candidate extraction pipeline:

- Define `memory_candidates` domain schema.
- Add `POST /v1/memory/candidates`.
- Add candidate extraction prompt runner stub.
- Add candidate review/promote/reject flow.
- Enforce source evidence before promotion.
- Add initial policy pre-check hooks.
