# Roadmap

## Layer 0: Foundation Scaffold

Status: complete.

- Repository structure
- Domain schemas
- API shell
- SDK shell
- CLI shell
- Docs, ADRs, policies, prompts
- Project adapter template

## Layer 1: Durable Store

Status: complete for first scaffold.

- PostgreSQL connection
- Migration runner
- Event repository
- Memory repository
- Handoff repository
- Storage interface
- In-memory test/dev store
- Smoke test script

## Layer 2: Memory Ingestion

Status: next.

- Candidate extraction prompt runner
- Memory candidate schema
- Memory classifier
- Policy pre-check
- Evidence enforcement
- Candidate review workflow
- Candidate-to-memory promotion

## Layer 3: Context Builder

- Hybrid retrieval
- Context planning
- Token budgeting
- Context pack rendering
- Project profile import
- Citation/evidence bundle

## Layer 4: Handoff Compiler

- Handoff from current project state
- Handoff from recent episodes
- Markdown/JSON export
- Git-safe handoff output
- Project adapter handoff writer

## Layer 5: Governance and Evaluation

- Policy engine integration
- Memory quality evals
- Stale-memory detection
- Supersession engine
- Privacy and retention tests

## Layer 6: Developer Experience

- Web admin UI
- IDE integrations
- Chat client export formats
- GitHub issue/PR integrations
