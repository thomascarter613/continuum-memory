import type {
  ArtifactRecord,
  ArtifactSearchRequest,
  CreateArtifactRecord,
  CreateRepoIndexRun,
  RepoIndexRun,
  ContextRetrievalRequest,
  ContextRetrievalResult,
  CreateContextRetrievalRequest,
  CreateContextRetrievalResult,
  CreateMemoryCandidate,
  CreateLlmCallAudit,
  CreateLlmProviderConfig,
  CreateMemoryEvaluation,
  CreateMemoryEvent,
  CreateMemoryRecord,
  CreatePolicyDecision,
  HandoffCreateRequest,
  HandoffPack,
  LlmCallAudit,
  LlmProviderConfig,
  MemoryCandidate,
  MemoryCandidatePromotionResult,
  MemoryEvaluation,
  MemoryCandidateSearchRequest,
  MemoryEvent,
  MemoryRecord,
  MemorySearchRequest,
  PolicyDecision,
  PromoteMemoryCandidateRequest,
} from "@continuum/domain"

export interface StoreHealth {
  ok: boolean
  kind: "memory" | "postgres"
  details?: Record<string, unknown>
}

export interface ContinuumStore {
  kind: "memory" | "postgres"
  health(): Promise<StoreHealth>
  createEvent(input: CreateMemoryEvent): Promise<MemoryEvent>
  createMemory(input: CreateMemoryRecord): Promise<MemoryRecord>
  getMemory(id: string): Promise<MemoryRecord | null>
  searchMemory(input: MemorySearchRequest): Promise<MemoryRecord[]>
  listActiveMemories(input?: { projectId?: string }): Promise<MemoryRecord[]>
  createContextRetrievalRequest(input: CreateContextRetrievalRequest): Promise<ContextRetrievalRequest>
  createContextRetrievalResult(input: CreateContextRetrievalResult): Promise<ContextRetrievalResult>
  createCandidate(input: CreateMemoryCandidate): Promise<MemoryCandidate>
  getCandidate(id: string): Promise<MemoryCandidate | null>
  searchCandidates(input: MemoryCandidateSearchRequest): Promise<MemoryCandidate[]>
  promoteCandidate(id: string, input: PromoteMemoryCandidateRequest): Promise<MemoryCandidatePromotionResult | null>
  rejectCandidate(id: string, reason: string): Promise<MemoryCandidate | null>
  createPolicyDecision(input: CreatePolicyDecision): Promise<PolicyDecision>
  createMemoryEvaluation(input: CreateMemoryEvaluation): Promise<MemoryEvaluation>
  createHandoff(input: HandoffCreateRequest): Promise<HandoffPack>
  getHandoff(id: string): Promise<HandoffPack | null>
  upsertLlmProvider(input: CreateLlmProviderConfig): Promise<LlmProviderConfig>
  listLlmProviders(): Promise<LlmProviderConfig[]>
  createLlmCallAudit(input: CreateLlmCallAudit): Promise<LlmCallAudit>
  getLlmCallAudit(id: string): Promise<LlmCallAudit | null>
  createArtifact(input: CreateArtifactRecord): Promise<ArtifactRecord>
  getArtifact(id: string): Promise<ArtifactRecord | null>
  searchArtifacts(input: ArtifactSearchRequest): Promise<ArtifactRecord[]>
  createRepoIndexRun(input: CreateRepoIndexRun): Promise<RepoIndexRun>
}
