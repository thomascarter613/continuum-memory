#!/usr/bin/env bun

import { ContinuumClient } from "@continuum/sdk-js"

const [command, ...args] = process.argv.slice(2)

function help() {
  console.log(`continuum

Commands:
  health                         Check API health
  providers                      List configured LLM providers
  route <task>                   Route an LLM task to a provider
  prompt-compile <message>       Compile a prompt from user message only
  chat-dry-run <message>         Run a deterministic mock LLM chat request
  embed-dry-run <text>           Generate deterministic mock embedding vectors
  context-build <task>           Build a basic context pack
  handoff-create <objective>     Create a basic handoff pack
  handoff-compile <objective>    Compile a handoff from durable memory
  policy-check <purpose>         Run a policy check through the API
  eval-handoff <handoff-id>      Evaluate handoff completeness
  artifact-create <path>         Create a small artifact metadata record
  artifact-search <query>        Search artifact memory
  repo-index [path]              Index local repository files as artifacts

Environment:
  CONTINUUM_API_URL defaults to http://localhost:3030
`)
}

const client = new ContinuumClient(process.env.CONTINUUM_API_URL ?? "http://localhost:3030")

if (!command || command === "help" || command === "--help" || command === "-h") {
  help()
  process.exit(0)
}

if (command === "health") {
  console.log(JSON.stringify(await client.health(), null, 2))
} else if (command === "providers") {
  console.log(JSON.stringify(await client.listLlmProviders(), null, 2))
} else if (command === "route") {
  const task = args.join(" ") || "continue current software development task"
  console.log(
    JSON.stringify(
      await client.routeLlm({
        projectId: "demo",
        task,
        preferredProviderId: process.env.CONTINUUM_LLM_DEFAULT_PROVIDER ?? "mock",
        requiredCapabilities: ["chat"],
      }),
      null,
      2,
    ),
  )
} else if (command === "prompt-compile") {
  const userMessage = args.join(" ") || "Continue from durable memory."
  console.log(
    JSON.stringify(
      await client.compilePrompt({
        projectId: "demo",
        userMessage,
        systemInstruction: "Use Continuum durable memory context when present.",
      }),
      null,
      2,
    ),
  )
} else if (command === "chat-dry-run") {
  const message = args.join(" ") || "Confirm the LLM gateway is wired."
  console.log(
    JSON.stringify(
      await client.chat({
        projectId: "demo",
        providerId: "mock",
        messages: [{ role: "user", content: message }],
        execute: false,
      }),
      null,
      2,
    ),
  )
} else if (command === "embed-dry-run") {
  const input = args.join(" ") || "Continuum memory embedding smoke test"
  console.log(
    JSON.stringify(
      await client.embeddings({
        projectId: "demo",
        providerId: "mock",
        input: [input],
        execute: false,
      }),
      null,
      2,
    ),
  )
} else if (command === "context-build") {
  const task = args.join(" ") || "continue current software development task"
  console.log(
    JSON.stringify(
      await client.buildContext({
        task,
        include: ["project_state", "decisions", "procedures", "recent_episodes"],
      }),
      null,
      2,
    ),
  )
} else if (command === "handoff-create") {
  const objective = args.join(" ") || "continue current software development task"
  console.log(
    JSON.stringify(
      await client.createHandoff({
        title: "Continuum Handoff",
        objective,
        currentState: "Initial CLI-generated handoff.",
        nextActions: ["Replace placeholder state with retrieved project memory."],
      }),
      null,
      2,
    ),
  )
} else if (command === "policy-check") {
  const purpose = args.join(" ") || "verify governance policy path"
  console.log(
    JSON.stringify(
      await client.checkPolicy({
        action: "context.retrieve",
        projectId: "demo",
        purpose,
        sensitivity: "normal",
        payload: { source: "continuum-cli" },
      }),
      null,
      2,
    ),
  )
} else if (command === "eval-handoff") {
  const handoffId = args[0]
  if (!handoffId) {
    console.error("eval-handoff requires a handoff id")
    process.exit(1)
  }
  console.log(JSON.stringify(await client.evaluateHandoff({ handoffId }), null, 2))

} else if (command === "artifact-create") {
  const path = args[0] ?? "README.md"
  console.log(
    JSON.stringify(
      await client.createArtifact({
        artifactKind: "documentation",
        namespace: "demo/artifacts",
        projectId: "demo",
        uri: `file://${path}`,
        path,
        name: path.split("/").at(-1) ?? path,
        mimeType: "text/markdown",
        status: "active",
        metadata: { createdBy: "continuum-cli" },
      }),
      null,
      2,
    ),
  )
} else if (command === "artifact-search") {
  const query = args.join(" ") || "README"
  console.log(JSON.stringify(await client.searchArtifacts({ projectId: "demo", query }), null, 2))
} else if (command === "repo-index") {
  const rootPath = args[0] ?? "."
  console.log(
    JSON.stringify(
      await client.indexRepo({
        projectId: "demo",
        namespace: "demo/artifacts",
        rootPath,
        maxFiles: 200,
        maxBytesPerFile: 80_000,
        captureContent: false,
        dryRun: false,
      }),
      null,
      2,
    ),
  )
} else if (command === "handoff-compile") {
  const objective = args.join(" ") || "continue current software development task"
  console.log(
    JSON.stringify(
      await client.compileHandoff({
        title: "Continuum Compiled Handoff",
        objective,
        retrieval: { strategy: "handoff", minScore: 0.1, includeEvidence: true },
      }),
      null,
      2,
    ),
  )
} else {
  console.error(`Unknown command: ${command}`)
  help()
  process.exit(1)
}
