import { randomUUID } from "node:crypto"
import type {
  ContextRetrievalRequest,
  ContextRetrievalResult,
  CreateContextRetrievalRequest,
  CreateContextRetrievalResult,
  CreateMemoryCandidate,
  CreateMemoryEvent,
  CreateMemoryRecord,
  HandoffCreateRequest,
  HandoffPack,
  MemoryCandidate,
  MemoryCandidatePromotionResult,
  MemoryCandidateSearchRequest,
  MemoryEvent,
  MemoryRecord,
  MemorySearchRequest,
  PromoteMemoryCandidateRequest,
} from "@continuum/domain"
import { renderHandoffMarkdown } from "../lib/handoff-markdown"
import { now } from "../lib/time"
import type { ContinuumStore, StoreHealth } from "./types"

export class InMemoryContinuumStore implements ContinuumStore {
  readonly kind = "memory" as const

  private readonly events = new Map<string, MemoryEvent>()
  private readonly memories = new Map<string, MemoryRecord>()
  private readonly candidates = new Map<string, MemoryCandidate>()
  private readonly handoffs = new Map<string, HandoffPack>()
  private readonly retrievalRequests = new Map<string, ContextRetrievalRequest>()
  private readonly retrievalResults = new Map<string, ContextRetrievalResult>()

  async health(): Promise<StoreHealth> {
    return {
      ok: true,
      kind: this.kind,
      details: {
        events: this.events.size,
        memories: this.memories.size,
        candidates: this.candidates.size,
        handoffs: this.handoffs.size,
        retrievalRequests: this.retrievalRequests.size,
        retrievalResults: this.retrievalResults.size,
      },
    }
  }

  async createEvent(input: CreateMemoryEvent): Promise<MemoryEvent> {
    const event: MemoryEvent = {
      ...input,
      id: input.id ?? randomUUID(),
      occurredAt: input.occurredAt ?? now(),
      payload: input.payload ?? {},
    }
    this.events.set(event.id, event)
    return event
  }

  async createMemory(input: CreateMemoryRecord): Promise<MemoryRecord> {
    const timestamp = now()
    const memory: MemoryRecord = {
      ...input,
      id: input.id ?? randomUUID(),
      sourceEventIds: input.sourceEventIds ?? [],
      sourceArtifactIds: input.sourceArtifactIds ?? [],
      scope: input.scope ?? {},
      confidence: input.confidence ?? 0.5,
      sensitivity: input.sensitivity ?? "normal",
      status: input.status ?? "active",
      createdAt: input.createdAt ?? timestamp,
      updatedAt: input.updatedAt ?? timestamp,
    }

    if (memory.supersedes) {
      const superseded = this.memories.get(memory.supersedes)
      if (superseded && superseded.status !== "forgotten") {
        this.memories.set(superseded.id, {
          ...superseded,
          status: "superseded",
          supersededBy: memory.id,
          updatedAt: timestamp,
        })
      }
    }

    this.memories.set(memory.id, memory)
    return memory
  }

  async getMemory(id: string): Promise<MemoryRecord | null> {
    return this.memories.get(id) ?? null
  }

  async searchMemory(input: MemorySearchRequest): Promise<MemoryRecord[]> {
    const query = input.query?.toLowerCase()
    return [...this.memories.values()]
      .filter((memory) => input.includeSuperseded || memory.status !== "superseded")
      .filter((memory) => !input.namespace || memory.namespace === input.namespace)
      .filter((memory) => !input.memoryTypes || input.memoryTypes.includes(memory.memoryType))
      .filter(
        (memory) =>
          !input.projectId || memory.scope.projectId === input.projectId || memory.namespace.includes(input.projectId),
      )
      .filter((memory) => !query || memory.content.toLowerCase().includes(query))
      .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt))
      .slice(0, input.limit ?? 20)
  }

  async listActiveMemories(input?: { projectId?: string }): Promise<MemoryRecord[]> {
    return [...this.memories.values()]
      .filter((memory) => memory.status === "active")
      .filter(
        (memory) =>
          !input?.projectId || memory.scope.projectId === input.projectId || memory.namespace.includes(input.projectId),
      )
      .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt))
  }


  async createContextRetrievalRequest(input: CreateContextRetrievalRequest): Promise<ContextRetrievalRequest> {
    const request: ContextRetrievalRequest = {
      ...input,
      id: input.id ?? randomUUID(),
      include: input.include ?? [],
      parameters: input.parameters ?? {},
      createdAt: input.createdAt ?? now(),
    }
    this.retrievalRequests.set(request.id, request)
    return request
  }

  async createContextRetrievalResult(input: CreateContextRetrievalResult): Promise<ContextRetrievalResult> {
    const result: ContextRetrievalResult = {
      ...input,
      id: input.id ?? randomUUID(),
      reasons: input.reasons ?? [],
      createdAt: input.createdAt ?? now(),
    }
    this.retrievalResults.set(result.id, result)
    return result
  }

  async createCandidate(input: CreateMemoryCandidate): Promise<MemoryCandidate> {
    const timestamp = now()
    const candidate: MemoryCandidate = {
      ...input,
      id: input.id ?? randomUUID(),
      sourceEventIds: input.sourceEventIds ?? [],
      sourceArtifactIds: input.sourceArtifactIds ?? [],
      scope: input.scope ?? {},
      confidence: input.confidence ?? 0.5,
      sensitivity: input.sensitivity ?? "normal",
      status: input.status ?? "proposed",
      suggestedActions: input.suggestedActions ?? [],
      createdAt: input.createdAt ?? timestamp,
      updatedAt: input.updatedAt ?? timestamp,
    }
    this.candidates.set(candidate.id, candidate)
    return candidate
  }

  async getCandidate(id: string): Promise<MemoryCandidate | null> {
    return this.candidates.get(id) ?? null
  }

  async searchCandidates(input: MemoryCandidateSearchRequest): Promise<MemoryCandidate[]> {
    const query = input.query?.toLowerCase()
    return [...this.candidates.values()]
      .filter((candidate) => !input.namespace || candidate.namespace === input.namespace)
      .filter((candidate) => !input.candidateTypes || input.candidateTypes.includes(candidate.candidateType))
      .filter((candidate) => !input.statuses || input.statuses.includes(candidate.status))
      .filter(
        (candidate) =>
          !input.projectId || candidate.scope.projectId === input.projectId || candidate.namespace.includes(input.projectId),
      )
      .filter((candidate) => !query || candidate.content.toLowerCase().includes(query))
      .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt))
      .slice(0, input.limit ?? 20)
  }

  async promoteCandidate(
    id: string,
    input: PromoteMemoryCandidateRequest,
  ): Promise<MemoryCandidatePromotionResult | null> {
    const candidate = this.candidates.get(id)
    if (!candidate) return null

    const memory = await this.createMemory({
      memoryType: input.memoryType ?? candidate.suggestedMemoryType ?? "semantic",
      namespace: input.namespace ?? candidate.namespace,
      scope: candidate.scope,
      content: input.content ?? candidate.content,
      structuredContent: input.structuredContent ?? candidate.structuredContent,
      sourceEventIds: candidate.sourceEventIds,
      sourceArtifactIds: candidate.sourceArtifactIds,
      confidence: input.confidence ?? candidate.confidence,
      sensitivity: input.sensitivity ?? candidate.sensitivity,
      status: input.status ?? "active",
      supersedes: input.supersedes,
    })

    const updated: MemoryCandidate = {
      ...candidate,
      status: "promoted",
      promotedMemoryId: memory.id,
      reviewedAt: now(),
      updatedAt: now(),
    }
    this.candidates.set(updated.id, updated)
    return { candidate: updated, memory }
  }

  async rejectCandidate(id: string, reason: string): Promise<MemoryCandidate | null> {
    const candidate = this.candidates.get(id)
    if (!candidate) return null
    const updated: MemoryCandidate = {
      ...candidate,
      status: "rejected",
      rejectionReason: reason,
      reviewedAt: now(),
      updatedAt: now(),
    }
    this.candidates.set(updated.id, updated)
    return updated
  }

  async createHandoff(input: HandoffCreateRequest): Promise<HandoffPack> {
    const pack: HandoffPack = {
      id: randomUUID(),
      ...(input.projectId ? { projectId: input.projectId } : {}),
      title: input.title ?? "Continuum Handoff",
      objective: input.objective,
      markdown: renderHandoffMarkdown({
        title: input.title ?? "Continuum Handoff",
        objective: input.objective,
        currentState: input.currentState ?? "",
        acceptedDecisions: input.acceptedDecisions ?? [],
        openQuestions: input.openQuestions ?? [],
        nextActions: input.nextActions ?? [],
        artifactRefs: input.artifactRefs ?? [],
      }),
      payload: {
        title: input.title ?? "Continuum Handoff",
        objective: input.objective,
        currentState: input.currentState ?? "",
        acceptedDecisions: input.acceptedDecisions ?? [],
        openQuestions: input.openQuestions ?? [],
        nextActions: input.nextActions ?? [],
        artifactRefs: input.artifactRefs ?? [],
        ...(input.projectId ? { projectId: input.projectId } : {}),
      },
      createdAt: now(),
    }
    this.handoffs.set(pack.id, pack)
    return pack
  }

  async getHandoff(id: string): Promise<HandoffPack | null> {
    return this.handoffs.get(id) ?? null
  }
}
