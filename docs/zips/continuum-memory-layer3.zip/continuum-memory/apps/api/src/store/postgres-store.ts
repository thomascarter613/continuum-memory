import { randomUUID } from "node:crypto"
import type {
  ContextRetrievalRequest,
  ContextRetrievalResult,
  CreateContextRetrievalRequest,
  CreateContextRetrievalResult,
  CreateMemoryCandidate,
  CreateMemoryEvent,
  CreateMemoryRecord,
  HandoffCreateRequest,
  HandoffPack,
  MemoryCandidate,
  MemoryCandidatePromotionResult,
  MemoryCandidateSearchRequest,
  MemoryEvent,
  MemoryRecord,
  MemorySearchRequest,
  PromoteMemoryCandidateRequest,
} from "@continuum/domain"
import type { PgPool } from "../db/pool"
import { renderHandoffMarkdown } from "../lib/handoff-markdown"
import { now } from "../lib/time"
import {
  candidateFromRow,
  contextRetrievalRequestFromRow,
  contextRetrievalResultFromRow,
  eventFromRow,
  handoffFromRow,
  memoryFromRow,
} from "./postgres-mappers"
import type { ContinuumStore, StoreHealth } from "./types"

export class PostgresContinuumStore implements ContinuumStore {
  readonly kind = "postgres" as const

  constructor(private readonly pool: PgPool) {}

  async health(): Promise<StoreHealth> {
    const result = await this.pool.query<{
      events: string
      memories: string
      candidates: string
      handoffs: string
      retrieval_requests: string
      retrieval_results: string
    }>(`select
        (select count(*) from memory_events)::text as events,
        (select count(*) from memory_records)::text as memories,
        (select count(*) from memory_candidates)::text as candidates,
        (select count(*) from handoff_packs)::text as handoffs,
        (select count(*) from context_retrieval_requests)::text as retrieval_requests,
        (select count(*) from context_retrieval_results)::text as retrieval_results`)

    return {
      ok: true,
      kind: this.kind,
      details: {
        events: Number(result.rows[0]?.events ?? 0),
        memories: Number(result.rows[0]?.memories ?? 0),
        candidates: Number(result.rows[0]?.candidates ?? 0),
        handoffs: Number(result.rows[0]?.handoffs ?? 0),
        retrievalRequests: Number(result.rows[0]?.retrieval_requests ?? 0),
        retrievalResults: Number(result.rows[0]?.retrieval_results ?? 0),
      },
    }
  }

  async createEvent(input: CreateMemoryEvent): Promise<MemoryEvent> {
    const event: MemoryEvent = {
      ...input,
      id: input.id ?? randomUUID(),
      occurredAt: input.occurredAt ?? now(),
      payload: input.payload ?? {},
    }

    const result = await this.pool.query(
      `insert into memory_events (
        id, event_type, actor_type, actor_id, subject_type, subject_id,
        project_id, conversation_id, session_id, run_id, payload,
        occurred_at, causation_id, correlation_id
      ) values (
        $1, $2, $3, $4, $5, $6,
        $7, $8, $9, $10, $11::jsonb,
        $12::timestamptz, $13, $14
      ) returning *`,
      [
        event.id,
        event.eventType,
        event.actorType,
        event.actorId ?? null,
        event.subjectType ?? null,
        event.subjectId ?? null,
        event.projectId ?? null,
        event.conversationId ?? null,
        event.sessionId ?? null,
        event.runId ?? null,
        JSON.stringify(event.payload ?? {}),
        event.occurredAt,
        event.causationId ?? null,
        event.correlationId ?? null,
      ],
    )

    const row = result.rows[0]
    if (!row) throw new Error("Failed to insert memory event")
    return eventFromRow(row)
  }

  async createMemory(input: CreateMemoryRecord): Promise<MemoryRecord> {
    const timestamp = now()
    const memory: MemoryRecord = {
      ...input,
      id: input.id ?? randomUUID(),
      sourceEventIds: input.sourceEventIds ?? [],
      sourceArtifactIds: input.sourceArtifactIds ?? [],
      scope: input.scope ?? {},
      confidence: input.confidence ?? 0.5,
      sensitivity: input.sensitivity ?? "normal",
      status: input.status ?? "active",
      createdAt: input.createdAt ?? timestamp,
      updatedAt: input.updatedAt ?? timestamp,
    }

    const client = await this.pool.connect()
    try {
      await client.query("begin")
      const result = await client.query(
        `insert into memory_records (
          id, memory_type, namespace, scope, content, structured_content,
          source_event_ids, source_artifact_ids, confidence, sensitivity, status,
          valid_from, valid_to, supersedes, superseded_by, created_at, updated_at
        ) values (
          $1, $2, $3, $4::jsonb, $5, $6::jsonb,
          $7::uuid[], $8::uuid[], $9, $10, $11,
          $12::timestamptz, $13::timestamptz, $14, $15, $16::timestamptz, $17::timestamptz
        ) returning *`,
        [
          memory.id,
          memory.memoryType,
          memory.namespace,
          JSON.stringify(memory.scope),
          memory.content,
          memory.structuredContent ? JSON.stringify(memory.structuredContent) : null,
          memory.sourceEventIds,
          memory.sourceArtifactIds,
          memory.confidence,
          memory.sensitivity,
          memory.status,
          memory.validFrom ?? null,
          memory.validTo ?? null,
          memory.supersedes ?? null,
          memory.supersededBy ?? null,
          memory.createdAt,
          memory.updatedAt,
        ],
      )

      if (memory.supersedes) {
        await client.query(
          `update memory_records
           set status = 'superseded', superseded_by = $1, updated_at = now()
           where id = $2 and status <> 'forgotten'`,
          [memory.id, memory.supersedes],
        )
      }

      await client.query("commit")
      const row = result.rows[0]
      if (!row) throw new Error("Failed to insert memory record")
      return memoryFromRow(row)
    } catch (error) {
      await client.query("rollback")
      throw error
    } finally {
      client.release()
    }
  }

  async getMemory(id: string): Promise<MemoryRecord | null> {
    const result = await this.pool.query(`select * from memory_records where id = $1`, [id])
    const row = result.rows[0]
    if (!row) return null
    return memoryFromRow(row)
  }

  async searchMemory(input: MemorySearchRequest): Promise<MemoryRecord[]> {
    const where: string[] = []
    const params: unknown[] = []

    if (!input.includeSuperseded) {
      params.push("superseded")
      where.push(`status <> $${params.length}`)
    }

    if (input.namespace) {
      params.push(input.namespace)
      where.push(`namespace = $${params.length}`)
    }

    if (input.memoryTypes?.length) {
      params.push(input.memoryTypes)
      where.push(`memory_type = any($${params.length}::text[])`)
    }

    if (input.projectId) {
      params.push(JSON.stringify({ projectId: input.projectId }))
      const scopeParam = params.length
      params.push(`%${input.projectId}%`)
      const namespaceParam = params.length
      where.push(`(scope @> $${scopeParam}::jsonb or namespace ilike $${namespaceParam})`)
    }

    if (input.query) {
      params.push(`%${input.query}%`)
      where.push(`content ilike $${params.length}`)
    }

    params.push(input.limit ?? 20)
    const limitParam = params.length
    const sql = `select * from memory_records
      ${where.length ? `where ${where.join(" and ")}` : ""}
      order by updated_at desc
      limit $${limitParam}`

    const result = await this.pool.query(sql, params)
    return result.rows.map(memoryFromRow)
  }

  async listActiveMemories(input?: { projectId?: string }): Promise<MemoryRecord[]> {
    const params: unknown[] = ["active"]
    const where = [`status = $1`]

    if (input?.projectId) {
      params.push(JSON.stringify({ projectId: input.projectId }))
      const scopeParam = params.length
      params.push(`%${input.projectId}%`)
      const namespaceParam = params.length
      where.push(`(scope @> $${scopeParam}::jsonb or namespace ilike $${namespaceParam})`)
    }

    const result = await this.pool.query(
      `select * from memory_records where ${where.join(" and ")} order by updated_at desc`,
      params,
    )
    return result.rows.map(memoryFromRow)
  }


  async createContextRetrievalRequest(input: CreateContextRetrievalRequest): Promise<ContextRetrievalRequest> {
    const request: ContextRetrievalRequest = {
      ...input,
      id: input.id ?? randomUUID(),
      include: input.include ?? [],
      parameters: input.parameters ?? {},
      createdAt: input.createdAt ?? now(),
    }

    const result = await this.pool.query(
      `insert into context_retrieval_requests (
        id, project_id, task, query, strategy, include, max_input_tokens, parameters, created_at
      ) values (
        $1, $2, $3, $4, $5, $6::text[], $7, $8::jsonb, $9::timestamptz
      ) returning *`,
      [
        request.id,
        request.projectId ?? null,
        request.task,
        request.query ?? null,
        request.strategy,
        request.include,
        request.maxInputTokens,
        JSON.stringify(request.parameters ?? {}),
        request.createdAt,
      ],
    )

    const row = result.rows[0]
    if (!row) throw new Error("Failed to insert context retrieval request")
    return contextRetrievalRequestFromRow(row)
  }

  async createContextRetrievalResult(input: CreateContextRetrievalResult): Promise<ContextRetrievalResult> {
    const resultRecord: ContextRetrievalResult = {
      ...input,
      id: input.id ?? randomUUID(),
      reasons: input.reasons ?? [],
      createdAt: input.createdAt ?? now(),
    }

    const result = await this.pool.query(
      `insert into context_retrieval_results (
        id, request_id, memory_id, section_name, rank, score, reasons, included, estimated_tokens, created_at
      ) values (
        $1, $2, $3, $4, $5, $6, $7::text[], $8, $9, $10::timestamptz
      ) returning *`,
      [
        resultRecord.id,
        resultRecord.requestId,
        resultRecord.memoryId,
        resultRecord.sectionName,
        resultRecord.rank,
        resultRecord.score,
        resultRecord.reasons,
        resultRecord.included,
        resultRecord.estimatedTokens,
        resultRecord.createdAt,
      ],
    )

    const row = result.rows[0]
    if (!row) throw new Error("Failed to insert context retrieval result")
    return contextRetrievalResultFromRow(row)
  }

  async createCandidate(input: CreateMemoryCandidate): Promise<MemoryCandidate> {
    const timestamp = now()
    const candidate: MemoryCandidate = {
      ...input,
      id: input.id ?? randomUUID(),
      sourceEventIds: input.sourceEventIds ?? [],
      sourceArtifactIds: input.sourceArtifactIds ?? [],
      scope: input.scope ?? {},
      confidence: input.confidence ?? 0.5,
      sensitivity: input.sensitivity ?? "normal",
      status: input.status ?? "proposed",
      suggestedActions: input.suggestedActions ?? [],
      createdAt: input.createdAt ?? timestamp,
      updatedAt: input.updatedAt ?? timestamp,
    }

    const result = await this.pool.query(
      `insert into memory_candidates (
        id, candidate_type, namespace, scope, content, structured_content,
        source_event_ids, source_artifact_ids, confidence, sensitivity, status,
        rationale, suggested_memory_type, suggested_actions, created_at, updated_at
      ) values (
        $1, $2, $3, $4::jsonb, $5, $6::jsonb,
        $7::uuid[], $8::uuid[], $9, $10, $11,
        $12, $13, $14::text[], $15::timestamptz, $16::timestamptz
      ) returning *`,
      [
        candidate.id,
        candidate.candidateType,
        candidate.namespace,
        JSON.stringify(candidate.scope),
        candidate.content,
        candidate.structuredContent ? JSON.stringify(candidate.structuredContent) : null,
        candidate.sourceEventIds,
        candidate.sourceArtifactIds,
        candidate.confidence,
        candidate.sensitivity,
        candidate.status,
        candidate.rationale ?? null,
        candidate.suggestedMemoryType ?? null,
        candidate.suggestedActions,
        candidate.createdAt,
        candidate.updatedAt,
      ],
    )

    const row = result.rows[0]
    if (!row) throw new Error("Failed to insert memory candidate")
    return candidateFromRow(row)
  }

  async getCandidate(id: string): Promise<MemoryCandidate | null> {
    const result = await this.pool.query(`select * from memory_candidates where id = $1`, [id])
    const row = result.rows[0]
    if (!row) return null
    return candidateFromRow(row)
  }

  async searchCandidates(input: MemoryCandidateSearchRequest): Promise<MemoryCandidate[]> {
    const where: string[] = []
    const params: unknown[] = []

    if (input.namespace) {
      params.push(input.namespace)
      where.push(`namespace = $${params.length}`)
    }

    if (input.candidateTypes?.length) {
      params.push(input.candidateTypes)
      where.push(`candidate_type = any($${params.length}::text[])`)
    }

    if (input.statuses?.length) {
      params.push(input.statuses)
      where.push(`status = any($${params.length}::text[])`)
    }

    if (input.projectId) {
      params.push(JSON.stringify({ projectId: input.projectId }))
      const scopeParam = params.length
      params.push(`%${input.projectId}%`)
      const namespaceParam = params.length
      where.push(`(scope @> $${scopeParam}::jsonb or namespace ilike $${namespaceParam})`)
    }

    if (input.query) {
      params.push(`%${input.query}%`)
      where.push(`content ilike $${params.length}`)
    }

    params.push(input.limit ?? 20)
    const limitParam = params.length
    const sql = `select * from memory_candidates
      ${where.length ? `where ${where.join(" and ")}` : ""}
      order by updated_at desc
      limit $${limitParam}`

    const result = await this.pool.query(sql, params)
    return result.rows.map(candidateFromRow)
  }

  async promoteCandidate(
    id: string,
    input: PromoteMemoryCandidateRequest,
  ): Promise<MemoryCandidatePromotionResult | null> {
    const client = await this.pool.connect()
    try {
      await client.query("begin")
      const candidateResult = await client.query(`select * from memory_candidates where id = $1 for update`, [id])
      const candidateRow = candidateResult.rows[0]
      if (!candidateRow) {
        await client.query("rollback")
        return null
      }

      const candidate = candidateFromRow(candidateRow)
      const timestamp = now()
      const memory: MemoryRecord = {
        id: randomUUID(),
        memoryType: input.memoryType ?? candidate.suggestedMemoryType ?? "semantic",
        namespace: input.namespace ?? candidate.namespace,
        scope: candidate.scope,
        content: input.content ?? candidate.content,
        structuredContent: input.structuredContent ?? candidate.structuredContent,
        sourceEventIds: candidate.sourceEventIds,
        sourceArtifactIds: candidate.sourceArtifactIds,
        confidence: input.confidence ?? candidate.confidence,
        sensitivity: input.sensitivity ?? candidate.sensitivity,
        status: input.status ?? "active",
        supersedes: input.supersedes,
        createdAt: timestamp,
        updatedAt: timestamp,
      }

      const memoryResult = await client.query(
        `insert into memory_records (
          id, memory_type, namespace, scope, content, structured_content,
          source_event_ids, source_artifact_ids, confidence, sensitivity, status,
          supersedes, created_at, updated_at
        ) values (
          $1, $2, $3, $4::jsonb, $5, $6::jsonb,
          $7::uuid[], $8::uuid[], $9, $10, $11,
          $12, $13::timestamptz, $14::timestamptz
        ) returning *`,
        [
          memory.id,
          memory.memoryType,
          memory.namespace,
          JSON.stringify(memory.scope),
          memory.content,
          memory.structuredContent ? JSON.stringify(memory.structuredContent) : null,
          memory.sourceEventIds,
          memory.sourceArtifactIds,
          memory.confidence,
          memory.sensitivity,
          memory.status,
          memory.supersedes ?? null,
          memory.createdAt,
          memory.updatedAt,
        ],
      )

      if (memory.supersedes) {
        await client.query(
          `update memory_records
           set status = 'superseded', superseded_by = $1, updated_at = now()
           where id = $2 and status <> 'forgotten'`,
          [memory.id, memory.supersedes],
        )
      }

      const updatedCandidateResult = await client.query(
        `update memory_candidates
         set status = 'promoted', promoted_memory_id = $1, reviewed_at = now(), updated_at = now()
         where id = $2
         returning *`,
        [memory.id, id],
      )

      await client.query("commit")
      const memoryRow = memoryResult.rows[0]
      const updatedCandidateRow = updatedCandidateResult.rows[0]
      if (!memoryRow || !updatedCandidateRow) throw new Error("Failed to promote memory candidate")
      return {
        candidate: candidateFromRow(updatedCandidateRow),
        memory: memoryFromRow(memoryRow),
      }
    } catch (error) {
      await client.query("rollback")
      throw error
    } finally {
      client.release()
    }
  }

  async rejectCandidate(id: string, reason: string): Promise<MemoryCandidate | null> {
    const result = await this.pool.query(
      `update memory_candidates
       set status = 'rejected', rejection_reason = $1, reviewed_at = now(), updated_at = now()
       where id = $2
       returning *`,
      [reason, id],
    )
    const row = result.rows[0]
    if (!row) return null
    return candidateFromRow(row)
  }

  async createHandoff(input: HandoffCreateRequest): Promise<HandoffPack> {
    const pack: HandoffPack = {
      id: randomUUID(),
      ...(input.projectId ? { projectId: input.projectId } : {}),
      title: input.title ?? "Continuum Handoff",
      objective: input.objective,
      markdown: renderHandoffMarkdown({
        title: input.title ?? "Continuum Handoff",
        objective: input.objective,
        currentState: input.currentState ?? "",
        acceptedDecisions: input.acceptedDecisions ?? [],
        openQuestions: input.openQuestions ?? [],
        nextActions: input.nextActions ?? [],
        artifactRefs: input.artifactRefs ?? [],
      }),
      payload: {
        title: input.title ?? "Continuum Handoff",
        objective: input.objective,
        currentState: input.currentState ?? "",
        acceptedDecisions: input.acceptedDecisions ?? [],
        openQuestions: input.openQuestions ?? [],
        nextActions: input.nextActions ?? [],
        artifactRefs: input.artifactRefs ?? [],
        ...(input.projectId ? { projectId: input.projectId } : {}),
      },
      createdAt: now(),
    }

    const result = await this.pool.query(
      `insert into handoff_packs (id, project_id, title, objective, markdown, payload, created_at)
       values ($1, $2, $3, $4, $5, $6::jsonb, $7::timestamptz)
       returning *`,
      [
        pack.id,
        pack.projectId ?? null,
        pack.title,
        pack.objective,
        pack.markdown,
        JSON.stringify(pack.payload),
        pack.createdAt,
      ],
    )

    const row = result.rows[0]
    if (!row) throw new Error("Failed to insert handoff pack")
    return handoffFromRow(row)
  }

  async getHandoff(id: string): Promise<HandoffPack | null> {
    const result = await this.pool.query(`select * from handoff_packs where id = $1`, [id])
    const row = result.rows[0]
    if (!row) return null
    return handoffFromRow(row)
  }
}
