# Current State

## Active Objective

Build Continuum Memory: a model-agnostic persistent memory and context control plane for software-development assistance.

## Current Phase

Layer 3 context retrieval and context pack building is complete for the first scaffold. The system is ready for Layer 4 handoff compiler work.

## Accepted Decisions

- Build Continuum Memory as a separate reusable monorepo.
- Use repo-local `.memory/` adapters in product monorepos.
- Use PostgreSQL as canonical memory store.
- Treat vector stores as indexes, not source of truth.
- Make handoff packs first-class artifacts.
- Use a storage interface so the API is not coupled to one persistence implementation.
- Keep in-memory storage only for tests and throwaway development.
- Use memory candidates as a reviewable buffer before durable memory writes.
- Build context through an explicit context plan rather than dumping all active memories into a prompt.
- Audit retrieval requests and included retrieval results.

## Layer 1 Completed

- Added `ContinuumStore` interface.
- Added `InMemoryContinuumStore`.
- Added `PostgresContinuumStore`.
- Added PostgreSQL pool and migration runner.
- Added durable persistence for `memory_events`, `memory_records`, and `handoff_packs`.
- Added supersession update behavior when a new memory supersedes an old memory.
- Added smoke-test script.
- Added durable-store ADR and work packet.

## Layer 2 Completed

- Added `memory_candidates` domain model.
- Added `memory_candidates` PostgreSQL table and indexes.
- Added candidate create, read, search, promote, and reject storage methods.
- Added candidate lifecycle API endpoints.
- Added deterministic heuristic candidate extraction endpoint for local testing.
- Added SDK candidate methods.
- Updated smoke test to exercise candidate create, promotion, extraction, rejection, and search.
- Added ADR-0005 and WP-0003.

## Layer 3 Completed

- Added context plan domain schema.
- Added ranked context memory schema.
- Added context evidence/citation schema.
- Added retrieval request/result audit domain schema.
- Added `context_retrieval_requests` and `context_retrieval_results` tables.
- Added retrieval audit persistence to in-memory and PostgreSQL stores.
- Added `/v1/context/plan` endpoint.
- Replaced simple context build with a section-aware context builder.
- Added scoring by section fit, task/query overlap, confidence, recency, evidence, sensitivity, and project scope.
- Added section-level max memory count and overall token-budget enforcement.
- Added retrieval audit id to context packs.
- Added citations/evidence metadata to context packs.
- Updated SDK and smoke test for context planning/building.
- Added ADR-0006 and WP-0004.

## Next Recommended Layer

Layer 4 should build the handoff compiler:

- Generate handoffs from current durable project memory.
- Include context pack excerpts, recent episodes, decisions, open tasks, and risks.
- Add JSON and Markdown handoff export format contracts.
- Add project-adapter handoff writer.
- Add `POST /v1/handoffs/from-context` or `POST /v1/handoffs/compile`.
- Add Git-safe handoff output conventions for product repos.
