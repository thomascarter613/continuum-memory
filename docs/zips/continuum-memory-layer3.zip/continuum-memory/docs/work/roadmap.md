# Roadmap

## Layer 0: Foundation Scaffold

Status: complete.

- Repository structure
- Domain schemas
- API shell
- SDK shell
- CLI shell
- Docs, ADRs, policies, prompts
- Project adapter template

## Layer 1: Durable Store

Status: complete for first scaffold.

- PostgreSQL connection
- Migration runner
- Event repository
- Memory repository
- Handoff repository
- Storage interface
- In-memory test/dev store
- Smoke test script

## Layer 2: Memory Ingestion

Status: complete for first scaffold.

- Memory candidate schema
- Candidate persistence
- Candidate search
- Candidate review workflow
- Candidate-to-memory promotion
- Candidate rejection with reason
- Deterministic heuristic extraction endpoint
- Smoke-test coverage

Deferred to later layers:

- LLM-based extraction
- Policy pre-check enforcement
- Human approval UI
- Evidence scoring

## Layer 3: Context Builder

Status: complete for first scaffold.

- Retrieval request/result audit records
- Context plan schema
- Section-aware retrieval scaffolding
- Relevance ranking
- Token budgeting per section
- Context pack assembly
- Citation/evidence bundle
- Context planning endpoint
- Audited context build endpoint

Deferred to later layers:

- Embedding-backed similarity retrieval
- pgvector ranking
- Qdrant synchronization
- Retrieval authorization policy enforcement
- Learned reranking

## Layer 4: Handoff Compiler

Status: next.

- Handoff from current project state
- Handoff from recent episodes
- Handoff from ranked context packs
- Markdown/JSON export
- Git-safe handoff output
- Project adapter handoff writer

## Layer 5: Governance and Evaluation

- Policy engine integration
- Memory quality evals
- Stale-memory detection
- Supersession engine
- Privacy and retention tests

## Layer 6: Developer Experience

- Web admin UI
- IDE integrations
- Chat client export formats
- GitHub issue/PR integrations
