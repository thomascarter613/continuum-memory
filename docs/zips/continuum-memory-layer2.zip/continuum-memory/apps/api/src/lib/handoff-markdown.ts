export function renderHandoffMarkdown(input: {
  title: string
  objective: string
  currentState: string
  acceptedDecisions: string[]
  openQuestions: string[]
  nextActions: string[]
  artifactRefs: string[]
}) {
  const list = (items: string[]) => (items.length ? items.map((item) => `- ${item}`).join("\n") : "- None")

  return `# ${input.title}

## Objective

${input.objective}

## Current State

${input.currentState || "No current state supplied."}

## Accepted Decisions

${list(input.acceptedDecisions)}

## Open Questions

${list(input.openQuestions)}

## Next Actions

${list(input.nextActions)}

## Artifact References

${list(input.artifactRefs)}
`
}
