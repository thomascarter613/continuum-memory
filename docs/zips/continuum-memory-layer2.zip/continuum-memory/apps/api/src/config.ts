export type ContinuumStoreKind = "memory" | "postgres"

export interface ContinuumConfig {
  apiPort: number
  storeKind: ContinuumStoreKind
  databaseUrl: string
  migrationsDir: string
  defaultContextBudgetTokens: number
}

function parseStoreKind(value: string | undefined): ContinuumStoreKind {
  if (value === "memory" || value === "postgres") return value
  return "postgres"
}

function parseInteger(value: string | undefined, fallback: number) {
  if (!value) return fallback
  const parsed = Number(value)
  return Number.isInteger(parsed) && parsed > 0 ? parsed : fallback
}

export function getConfig(): ContinuumConfig {
  return {
    apiPort: parseInteger(process.env.CONTINUUM_API_PORT, 3030),
    storeKind: parseStoreKind(process.env.CONTINUUM_STORE ?? process.env.CONTINUUM_STORAGE_DRIVER),
    databaseUrl:
      process.env.CONTINUUM_DATABASE_URL ??
      process.env.DATABASE_URL ??
      "postgres://continuum:continuum@localhost:5432/continuum",
    migrationsDir: process.env.CONTINUUM_MIGRATIONS_DIR ?? "infra/migrations",
    defaultContextBudgetTokens: parseInteger(process.env.CONTINUUM_DEFAULT_CONTEXT_BUDGET_TOKENS, 12000),
  }
}
