import type { HandoffPack, MemoryCandidate, MemoryEvent, MemoryRecord } from "@continuum/domain"

function iso(value: Date | string | null | undefined) {
  if (!value) return undefined
  if (value instanceof Date) return value.toISOString()
  return new Date(value).toISOString()
}

export function eventFromRow(row: Record<string, unknown>): MemoryEvent {
  const event: MemoryEvent = {
    id: String(row.id),
    eventType: String(row.event_type),
    actorType: String(row.actor_type),
    payload: (row.payload as Record<string, unknown>) ?? {},
    occurredAt: iso(row.occurred_at as Date | string) ?? new Date().toISOString(),
  }

  if (row.actor_id) event.actorId = String(row.actor_id)
  if (row.subject_type) event.subjectType = String(row.subject_type)
  if (row.subject_id) event.subjectId = String(row.subject_id)
  if (row.project_id) event.projectId = String(row.project_id)
  if (row.conversation_id) event.conversationId = String(row.conversation_id)
  if (row.session_id) event.sessionId = String(row.session_id)
  if (row.run_id) event.runId = String(row.run_id)
  if (row.causation_id) event.causationId = String(row.causation_id)
  if (row.correlation_id) event.correlationId = String(row.correlation_id)

  return event
}

export function memoryFromRow(row: Record<string, unknown>): MemoryRecord {
  const memory: MemoryRecord = {
    id: String(row.id),
    memoryType: row.memory_type as MemoryRecord["memoryType"],
    namespace: String(row.namespace),
    scope: (row.scope as Record<string, unknown>) ?? {},
    content: String(row.content),
    sourceEventIds: (row.source_event_ids as string[]) ?? [],
    sourceArtifactIds: (row.source_artifact_ids as string[]) ?? [],
    confidence: Number(row.confidence ?? 0.5),
    sensitivity: row.sensitivity as MemoryRecord["sensitivity"],
    status: row.status as MemoryRecord["status"],
    createdAt: iso(row.created_at as Date | string) ?? new Date().toISOString(),
    updatedAt: iso(row.updated_at as Date | string) ?? new Date().toISOString(),
  }

  if (row.structured_content) memory.structuredContent = row.structured_content as Record<string, unknown>
  const validFrom = iso(row.valid_from as Date | string | null)
  const validTo = iso(row.valid_to as Date | string | null)
  if (validFrom) memory.validFrom = validFrom
  if (validTo) memory.validTo = validTo
  if (row.supersedes) memory.supersedes = String(row.supersedes)
  if (row.superseded_by) memory.supersededBy = String(row.superseded_by)

  return memory
}


export function candidateFromRow(row: Record<string, unknown>): MemoryCandidate {
  const candidate: MemoryCandidate = {
    id: String(row.id),
    candidateType: row.candidate_type as MemoryCandidate["candidateType"],
    namespace: String(row.namespace),
    scope: (row.scope as Record<string, unknown>) ?? {},
    content: String(row.content),
    sourceEventIds: (row.source_event_ids as string[]) ?? [],
    sourceArtifactIds: (row.source_artifact_ids as string[]) ?? [],
    confidence: Number(row.confidence ?? 0.5),
    sensitivity: row.sensitivity as MemoryCandidate["sensitivity"],
    status: row.status as MemoryCandidate["status"],
    suggestedActions: (row.suggested_actions as string[]) ?? [],
    createdAt: iso(row.created_at as Date | string) ?? new Date().toISOString(),
    updatedAt: iso(row.updated_at as Date | string) ?? new Date().toISOString(),
  }

  if (row.structured_content) candidate.structuredContent = row.structured_content as Record<string, unknown>
  if (row.rationale) candidate.rationale = String(row.rationale)
  if (row.suggested_memory_type) candidate.suggestedMemoryType = row.suggested_memory_type as MemoryCandidate["suggestedMemoryType"]
  if (row.rejection_reason) candidate.rejectionReason = String(row.rejection_reason)
  if (row.promoted_memory_id) candidate.promotedMemoryId = String(row.promoted_memory_id)
  const reviewedAt = iso(row.reviewed_at as Date | string | null)
  if (reviewedAt) candidate.reviewedAt = reviewedAt

  return candidate
}

export function handoffFromRow(row: Record<string, unknown>): HandoffPack {
  const handoff: HandoffPack = {
    id: String(row.id),
    title: String(row.title),
    objective: String(row.objective),
    markdown: String(row.markdown),
    payload: row.payload as HandoffPack["payload"],
    createdAt: iso(row.created_at as Date | string) ?? new Date().toISOString(),
  }

  if (row.project_id) handoff.projectId = String(row.project_id)

  return handoff
}
