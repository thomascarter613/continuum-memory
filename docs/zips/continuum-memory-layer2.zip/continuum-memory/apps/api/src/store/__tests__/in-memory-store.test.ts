import { describe, expect, test } from "bun:test"
import { InMemoryContinuumStore } from "../in-memory-store"

describe("InMemoryContinuumStore", () => {
  test("creates and retrieves a memory record", async () => {
    const store = new InMemoryContinuumStore()
    const created = await store.createMemory({
      memoryType: "semantic",
      namespace: "project:test",
      content: "The test project uses durable memory.",
      scope: { projectId: "test" },
    })

    const found = await store.getMemory(created.id)
    expect(found?.content).toBe("The test project uses durable memory.")
  })

  test("searches active non-superseded memories", async () => {
    const store = new InMemoryContinuumStore()
    await store.createMemory({
      memoryType: "semantic",
      namespace: "project:test",
      content: "Use PostgreSQL as canonical memory store.",
      scope: { projectId: "test" },
    })
    await store.createMemory({
      memoryType: "semantic",
      namespace: "project:test",
      content: "Old vector-only design.",
      scope: { projectId: "test" },
      status: "superseded",
    })

    const results = await store.searchMemory({ query: "store", limit: 10, includeSuperseded: false })
    expect(results).toHaveLength(1)
    expect(results[0]?.content).toContain("PostgreSQL")
  })

  test("creates, searches, promotes, and rejects memory candidates", async () => {
    const store = new InMemoryContinuumStore()
    const candidate = await store.createCandidate({
      candidateType: "decision",
      namespace: "project:test",
      scope: { projectId: "test" },
      content: "Decision: use PostgreSQL as the canonical memory store.",
      confidence: 0.91,
      suggestedMemoryType: "decision",
    })

    const candidates = await store.searchCandidates({ query: "PostgreSQL", projectId: "test", limit: 10 })
    expect(candidates).toHaveLength(1)

    const promoted = await store.promoteCandidate(candidate.id, {})
    expect(promoted?.memory.memoryType).toBe("decision")
    expect(promoted?.candidate.status).toBe("promoted")

    const rejectable = await store.createCandidate({
      candidateType: "unknown",
      namespace: "project:test",
      content: "This is too trivial to remember.",
    })
    const rejected = await store.rejectCandidate(rejectable.id, "Trivial and not durable.")
    expect(rejected?.status).toBe("rejected")
    expect(rejected?.rejectionReason).toContain("Trivial")
  })
})
