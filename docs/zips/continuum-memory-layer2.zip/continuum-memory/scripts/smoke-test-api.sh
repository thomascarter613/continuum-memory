#!/usr/bin/env bash
set -euo pipefail

BASE_URL="${CONTINUUM_API_URL:-http://localhost:3030}"
EVENT_ID="$(bun -e 'console.log(crypto.randomUUID())')"
MEMORY_ID="$(bun -e 'console.log(crypto.randomUUID())')"
CANDIDATE_ID="$(bun -e 'console.log(crypto.randomUUID())')"

TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT

jq_required() {
  if ! command -v jq >/dev/null 2>&1; then
    echo "jq is required for the Layer 2 smoke test." >&2
    exit 1
  fi
}

jq_required

echo "Checking health..."
curl -fsS "$BASE_URL/healthz"
echo

echo "Creating event $EVENT_ID..."
curl -fsS -X POST "$BASE_URL/v1/events" \
  -H 'content-type: application/json' \
  -d "{
    \"id\":\"$EVENT_ID\",
    \"eventType\":\"message.received\",
    \"actorType\":\"user\",
    \"actorId\":\"local-dev\",
    \"projectId\":\"demo\",
    \"payload\":{\"text\":\"Use PostgreSQL as canonical memory store.\"}
  }"
echo

echo "Creating memory $MEMORY_ID..."
curl -fsS -X POST "$BASE_URL/v1/memory" \
  -H 'content-type: application/json' \
  -d "{
    \"id\":\"$MEMORY_ID\",
    \"memoryType\":\"decision\",
    \"namespace\":\"project:demo/decisions\",
    \"scope\":{\"projectId\":\"demo\"},
    \"content\":\"Use PostgreSQL as the canonical memory store and treat vector stores as indexes.\",
    \"sourceEventIds\":[\"$EVENT_ID\"],
    \"confidence\":0.95
  }"
echo

echo "Creating candidate $CANDIDATE_ID..."
curl -fsS -X POST "$BASE_URL/v1/memory/candidates" \
  -H 'content-type: application/json' \
  -d "{
    \"id\":\"$CANDIDATE_ID\",
    \"candidateType\":\"decision\",
    \"namespace\":\"project:demo/decisions\",
    \"scope\":{\"projectId\":\"demo\"},
    \"content\":\"Decision: memory candidates must be reviewed before promotion.\",
    \"sourceEventIds\":[\"$EVENT_ID\"],
    \"confidence\":0.9,
    \"suggestedMemoryType\":\"decision\",
    \"suggestedActions\":[\"review\",\"promote_or_reject\"]
  }"
echo

echo "Promoting candidate $CANDIDATE_ID..."
curl -fsS -X POST "$BASE_URL/v1/memory/candidates/$CANDIDATE_ID/promote" \
  -H 'content-type: application/json' \
  -d '{}' > "$TMP_DIR/promoted.json"
cat "$TMP_DIR/promoted.json"
echo

echo "Extracting candidates from text..."
curl -fsS -X POST "$BASE_URL/v1/memory/candidates/extract" \
  -H 'content-type: application/json' \
  -d "{
    \"namespace\":\"project:demo/session\",
    \"projectId\":\"demo\",
    \"sourceEventIds\":[\"$EVENT_ID\"],
    \"text\":\"Going forward, prefer explicit handoff packs at session boundaries. Next action: add policy hooks for candidate review. Open question: should promotion require human approval?\"
  }" > "$TMP_DIR/extracted.json"
cat "$TMP_DIR/extracted.json"
echo

REJECT_ID="$(jq -r '.candidates[-1].id' "$TMP_DIR/extracted.json")"
echo "Rejecting extracted candidate $REJECT_ID..."
curl -fsS -X POST "$BASE_URL/v1/memory/candidates/$REJECT_ID/reject" \
  -H 'content-type: application/json' \
  -d '{"reason":"Smoke test rejection path."}'
echo

echo "Reading memory $MEMORY_ID..."
curl -fsS "$BASE_URL/v1/memory/$MEMORY_ID"
echo

echo "Searching memory..."
curl -fsS -X POST "$BASE_URL/v1/memory/search" \
  -H 'content-type: application/json' \
  -d '{"projectId":"demo","query":"PostgreSQL","limit":10}'
echo

echo "Searching candidates..."
curl -fsS -X POST "$BASE_URL/v1/memory/candidates/search" \
  -H 'content-type: application/json' \
  -d '{"projectId":"demo","limit":10}'
echo

echo "Building context..."
curl -fsS -X POST "$BASE_URL/v1/context/build" \
  -H 'content-type: application/json' \
  -d '{"projectId":"demo","task":"continue architecture implementation","include":["decisions","project_state"]}'
echo

echo "Creating handoff..."
curl -fsS -X POST "$BASE_URL/v1/handoffs" \
  -H 'content-type: application/json' \
  -d '{
    "projectId":"demo",
    "title":"Demo Handoff",
    "objective":"Resume durable memory implementation.",
    "currentState":"Layer 2 memory ingestion has been added.",
    "acceptedDecisions":["Use PostgreSQL as canonical store.","Review candidates before promotion."],
    "nextActions":["Add policy hooks for memory candidate review."]
  }'
echo
