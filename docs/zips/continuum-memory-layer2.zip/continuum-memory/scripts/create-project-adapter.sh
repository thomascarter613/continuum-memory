#!/usr/bin/env bash
set -euo pipefail

TARGET="${1:-}"

if [ -z "$TARGET" ]; then
  echo "Usage: ./scripts/create-project-adapter.sh /path/to/project-repo" >&2
  exit 1
fi

if [ ! -d "$TARGET" ]; then
  echo "Target directory does not exist: $TARGET" >&2
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
TEMPLATE_DIR="$ROOT_DIR/templates/project-adapter"

mkdir -p "$TARGET/.memory" "$TARGET/docs/work" "$TARGET/docs/adr" "$TARGET/docs/handoffs"
cp -R "$TEMPLATE_DIR/." "$TARGET/"

echo "Continuum project adapter installed in: $TARGET"
echo "Next: edit $TARGET/.memory/project.yaml and $TARGET/docs/work/current-state.md"
