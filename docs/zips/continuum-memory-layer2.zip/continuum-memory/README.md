# Continuum Memory

Continuum Memory is a model-agnostic persistent memory and context control plane for software-development agents and LLM-assisted work.


## Canonical repository

This project is intended to live at:

```txt
https://github.com/thomascarter613/continuum-memory.git
```

It is designed around this rule:

> Chats are disposable. Memory is durable. Context is assembled. Handoffs are explicit artifacts.

This repository is the reusable memory system itself. Product/application monorepos should not embed this whole system. Instead, product repos should include a thin `.memory/` adapter, `AGENTS.md`, ADRs, work packets, current-state docs, and handoff files.

## Layer 2 status

Layer 2 adds the first **memory ingestion** workflow.

Included now:

- Bun workspace
- TypeScript packages
- Hono API
- shared domain schemas
- JavaScript SDK shell
- CLI shell
- PostgreSQL-backed storage repositories
- in-memory storage implementation for tests/dev
- migration runner
- SQL migrations for events, memory records, semantic facts, handoff packs, and memory candidates
- Docker Compose for Postgres/pgvector, Qdrant, Valkey, and MinIO
- memory candidate create/search/review APIs
- memory candidate promotion into durable memory records
- memory candidate rejection with review reason
- heuristic candidate extraction endpoint for local testing
- smoke-test script covering candidate creation, promotion, extraction, rejection, memory search, context build, and handoff creation
- memory taxonomy docs
- ADRs
- work planning docs
- OPA/Rego policy stubs
- prompt templates
- project-adapter template for other monorepos

Still intentionally deferred to later layers:

- LLM-based candidate extraction with provider routing
- policy enforcement runtime for candidate review
- pgvector embedding writes and semantic retrieval
- Qdrant synchronization
- artifact/blob indexing
- temporal knowledge graph
- admin UI

## Quickstart with durable PostgreSQL storage

```bash
cp .env.example .env
bun install
bun run infra:up
bun run db:migrate
bun run dev
```

In another terminal:

```bash
curl http://localhost:3030/healthz
```

Expected shape:

```json
{
  "ok": true,
  "service": "continuum-memory-api",
  "store": {
    "ok": true,
    "kind": "postgres"
  }
}
```

Run the smoke test:

```bash
bun run smoke:api
```

The smoke test creates a memory event, writes a decision memory, creates and promotes a candidate, extracts additional candidates from text, rejects one candidate, searches memory, searches candidates, builds a context pack, and creates a handoff pack.

## Quickstart with process-local in-memory storage

Use this only for throwaway development or tests:

```bash
cp .env.example .env
printf '\nCONTINUUM_STORE=memory\n' >> .env
bun install
bun run dev
```

The in-memory store is useful for API shape testing, but it does not survive process restarts.

## Recommended workspace layout

```txt
Workspace/
├── continuum-memory/       # this reusable memory system
├── your-product-monorepo/  # product repo using a thin .memory adapter
└── .continuum-data/        # local runtime data, not committed
```

## Apply the project adapter to another repo

From this repository:

```bash
./scripts/create-project-adapter.sh ../your-product-monorepo
```

This copies the template files that let Continuum understand a software project.

## Main concepts

- **Working memory**: current run/session/task state.
- **Episodic memory**: what happened, when, and with what evidence.
- **Semantic memory**: durable facts, preferences, project state, and stable knowledge.
- **Procedural memory**: reusable workflows, runbooks, prompts, and executable skills.
- **Decision memory**: ADR-like decision records with rationale and alternatives.
- **Artifact memory**: files, generated outputs, logs, diagrams, and external documents.
- **Handoff memory**: portable state packages for resuming work in new chats or models.
- **Memory candidate**: a proposed memory that has evidence but has not yet been accepted as durable memory.

## Candidate lifecycle

```txt
observed text/event/tool result
→ memory candidate
→ review
→ promote to durable memory OR reject with reason
```

Layer 2 implements the storage and API foundation for this lifecycle.

## Development commands

```bash
bun run infra:up
bun run db:migrate
bun run dev
bun run smoke:api
bun run format
bun run lint
bun run typecheck
bun run test
bun run check
```

## API endpoints

```txt
GET  /healthz
POST /v1/events
POST /v1/memory
GET  /v1/memory/:id
POST /v1/memory/search
POST /v1/memory/candidates
POST /v1/memory/candidates/extract
POST /v1/memory/candidates/search
GET  /v1/memory/candidates/:id
POST /v1/memory/candidates/:id/promote
POST /v1/memory/candidates/:id/reject
POST /v1/context/build
POST /v1/handoffs
GET  /v1/handoffs/:id
```

## Candidate examples

Create a candidate:

```bash
curl -X POST http://localhost:3030/v1/memory/candidates \
  -H 'content-type: application/json' \
  -d '{
    "candidateType":"decision",
    "namespace":"project:demo/decisions",
    "scope":{"projectId":"demo"},
    "content":"Decision: memory candidates must be reviewed before promotion.",
    "confidence":0.9,
    "suggestedMemoryType":"decision"
  }'
```

Extract candidates from text:

```bash
curl -X POST http://localhost:3030/v1/memory/candidates/extract \
  -H 'content-type: application/json' \
  -d '{
    "namespace":"project:demo/session",
    "projectId":"demo",
    "text":"Going forward, prefer explicit handoff packs. Next action: add policy hooks. Open question: should promotion require human approval?"
  }'
```

Promote a candidate:

```bash
curl -X POST http://localhost:3030/v1/memory/candidates/<candidate-id>/promote \
  -H 'content-type: application/json' \
  -d '{}'
```

Reject a candidate:

```bash
curl -X POST http://localhost:3030/v1/memory/candidates/<candidate-id>/reject \
  -H 'content-type: application/json' \
  -d '{"reason":"Too trivial to preserve as durable memory."}'
```

## Storage contract

The API depends on a storage interface, not a concrete database implementation. Current implementations:

```txt
apps/api/src/store/in-memory-store.ts
apps/api/src/store/postgres-store.ts
```

Use PostgreSQL for real work:

```env
CONTINUUM_STORE=postgres
CONTINUUM_DATABASE_URL=postgres://continuum:continuum@localhost:5432/continuum
```

Use memory only for throwaway tests:

```env
CONTINUUM_STORE=memory
```
