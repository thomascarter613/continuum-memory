#!/usr/bin/env bash
set -euo pipefail

curl -sS -X POST http://localhost:3030/v1/context/build \
  -H 'content-type: application/json' \
  -d '{
    "projectId": "continuum-memory",
    "task": "continue implementing durable memory persistence",
    "include": ["project_state", "decisions", "procedures", "recent_episodes"]
  }' | jq .
