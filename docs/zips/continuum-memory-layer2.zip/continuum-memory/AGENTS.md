# Agent Instructions

This repository implements Continuum Memory, a model-agnostic persistent memory and context control plane.

## Operating doctrine

- Treat chats as disposable and memory as durable.
- Do not store raw private data in Git.
- Every durable memory must have evidence.
- Vector stores are indexes, not source of truth.
- PostgreSQL is the planned canonical store.
- Handoffs are typed artifacts, not casual summaries.
- Project repos get a thin `.memory/` adapter; this repo contains the reusable memory platform.

## Before changing code

1. Read `docs/work/current-state.md`.
2. Read `docs/adr/`.
3. Read the relevant package or app README if present.
4. Prefer small, verifiable changes.
5. Update docs, ADRs, and current-state when decisions change.

## Verification commands

```bash
bun run format
bun run lint
bun run typecheck
bun run test
bun run check
```

## Memory-specific rules

- Do not commit raw chat transcripts.
- Do not commit `.continuum-data/` or database volumes.
- Do not commit embeddings, vector indexes, secrets, or private user memory.
- Commit project-safe docs, schemas, policy, prompts, ADRs, and handoff templates.
