# Current State

## Active Objective

Build Continuum Memory: a model-agnostic persistent memory and context control plane for software-development assistance.

## Current Phase

Layer 2 memory ingestion scaffold is complete. The system is ready for Layer 3 context retrieval and context-builder refinement.

## Accepted Decisions

- Build Continuum Memory as a separate reusable monorepo.
- Use repo-local `.memory/` adapters in product monorepos.
- Use PostgreSQL as canonical memory store.
- Treat vector stores as indexes, not source of truth.
- Make handoff packs first-class artifacts.
- Use a storage interface so the API is not coupled to one persistence implementation.
- Keep in-memory storage only for tests and throwaway development.
- Use memory candidates as a reviewable buffer before durable memory writes.

## Layer 1 Completed

- Added `ContinuumStore` interface.
- Added `InMemoryContinuumStore`.
- Added `PostgresContinuumStore`.
- Added PostgreSQL pool and migration runner.
- Added durable persistence for `memory_events`, `memory_records`, and `handoff_packs`.
- Added supersession update behavior when a new memory supersedes an old memory.
- Added smoke-test script.
- Added durable-store ADR and work packet.

## Layer 2 Completed

- Added `memory_candidates` domain model.
- Added `memory_candidates` PostgreSQL table and indexes.
- Added candidate create, read, search, promote, and reject storage methods.
- Added candidate lifecycle API endpoints.
- Added deterministic heuristic candidate extraction endpoint for local testing.
- Added SDK candidate methods.
- Updated smoke test to exercise candidate create, promotion, extraction, rejection, and search.
- Added ADR-0005 and WP-0003.

## Next Recommended Layer

Layer 3 should refine retrieval and context building:

- Add retrieval request/result audit records.
- Add context plan schema.
- Rank memories by relevance, type, status, confidence, recency, and project scope.
- Add hard token budgeting per context section.
- Add evidence/citation metadata in context packs.
- Add candidate-aware context behavior so unpromoted candidates are excluded by default.
