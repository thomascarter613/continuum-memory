# Roadmap

## Layer 0: Foundation Scaffold

Status: complete.

- Repository structure
- Domain schemas
- API shell
- SDK shell
- CLI shell
- Docs, ADRs, policies, prompts
- Project adapter template

## Layer 1: Durable Store

Status: complete for first scaffold.

- PostgreSQL connection
- Migration runner
- Event repository
- Memory repository
- Handoff repository
- Storage interface
- In-memory test/dev store
- Smoke test script

## Layer 2: Memory Ingestion

Status: complete for first scaffold.

- Memory candidate schema
- Candidate persistence
- Candidate search
- Candidate review workflow
- Candidate-to-memory promotion
- Candidate rejection with reason
- Deterministic heuristic extraction endpoint
- Smoke-test coverage

Deferred to later layers:

- LLM-based extraction
- Policy pre-check enforcement
- Human approval UI
- Evidence scoring

## Layer 3: Context Builder

Status: complete for first scaffold.

- Retrieval request/result audit records
- Context plan schema
- Section-aware retrieval scaffolding
- Relevance ranking
- Token budgeting per section
- Context pack assembly
- Citation/evidence bundle
- Context planning endpoint
- Audited context build endpoint

Deferred to later layers:

- Embedding-backed similarity retrieval
- pgvector ranking
- Qdrant synchronization
- Retrieval authorization policy enforcement
- Learned reranking

## Layer 4: Handoff Compiler

Status: complete for first scaffold.

- Handoff from ranked context packs
- Handoff from durable project memory
- Decision, constraint, procedure, risk, open-question, verification, and next-action buckets
- Markdown/JSON compile response
- Source memory IDs
- Retrieval audit integration
- SDK compile method
- Smoke-test coverage

Deferred to later layers:

- Git-safe handoff file writer
- LLM-assisted narrative summarization
- Human approval flow
- Artifact/blob export bundle

## Layer 5: Governance and Evaluation

Status: next.

- Policy engine integration
- Memory quality evals
- Stale-memory detection
- Supersession engine
- Privacy and retention tests
- Handoff completeness scoring

## Layer 6: Developer Experience

- Web admin UI
- IDE integrations
- Chat client export formats
- GitHub issue/PR integrations


## Layer 5 Update: Governance and Evaluation

Layer 5 adds policy decisions, memory evaluations, handoff completeness scoring, evidence enforcement for durable memory writes, and governance/evaluation API surfaces.
