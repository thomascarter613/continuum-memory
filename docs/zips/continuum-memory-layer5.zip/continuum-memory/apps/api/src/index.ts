import { Hono } from "hono"
import { ZodError } from "zod"
import {
  ContextBuildRequestSchema,
  CreateMemoryCandidateSchema,
  CreateMemoryEventSchema,
  CreateMemoryRecordSchema,
  ExtractMemoryCandidatesRequestSchema,
  HandoffCompileRequestSchema,
  HandoffCompletenessEvaluationRequestSchema,
  HandoffCreateRequestSchema,
  MemoryCandidateSearchRequestSchema,
  MemoryQualityEvaluationRequestSchema,
  MemorySearchRequestSchema,
  PolicyCheckRequestSchema,
  PromoteMemoryCandidateRequestSchema,
  RejectMemoryCandidateRequestSchema,
  type MemoryCandidate,
  type MemoryRecord,
} from "@continuum/domain"
import { getConfig } from "./config"
import { extractMemoryCandidates } from "./lib/candidate-extraction"
import { buildContextPack } from "./lib/context-builder"
import { evaluateHandoffCompleteness, evaluateMemoryLike } from "./lib/evaluation-engine"
import { compileHandoff } from "./lib/handoff-compiler"
import { checkPolicy } from "./lib/policy-engine"
import { createStore, type ContinuumStore } from "./store"

const config = getConfig()
const store = createStore(config)
const app = createApp(store)

export function createApp(activeStore: ContinuumStore) {
  const api = new Hono()

  async function persistPolicyCheck(input: unknown) {
    const parsed = PolicyCheckRequestSchema.parse(input)
    const decision = checkPolicy(parsed)
    return activeStore.createPolicyDecision(decision)
  }

  api.onError((error, c) => {
    if (error instanceof ZodError) {
      return c.json({ error: "invalid_request", issues: error.issues }, 400)
    }

    console.error(error)
    return c.json(
      {
        error: "internal_error",
        message: error instanceof Error ? error.message : "Unknown error",
      },
      500,
    )
  })

  api.get("/healthz", async (c) => {
    try {
      const health = await activeStore.health()
      return c.json({ ok: health.ok, service: "continuum-memory-api", store: health })
    } catch (error) {
      return c.json(
        {
          ok: false,
          service: "continuum-memory-api",
          store: {
            ok: false,
            kind: activeStore.kind,
            message: error instanceof Error ? error.message : "Store health check failed",
          },
        },
        503,
      )
    }
  })



  api.post("/v1/policy/check", async (c) => {
    const body = await c.req.json()
    const decision = await persistPolicyCheck(body)
    if (decision.decision === "deny") {
      return c.json(decision, 403)
    }
    return c.json(decision)
  })

  api.post("/v1/evals/memory", async (c) => {
    const body = await c.req.json()
    const parsed = MemoryQualityEvaluationRequestSchema.parse(body)
    let target: MemoryRecord | MemoryCandidate | undefined = parsed.memory
    let targetType: "memory" | "candidate" = "memory"

    if (!target && parsed.memoryId) {
      target = await activeStore.getMemory(parsed.memoryId) ?? undefined
    }

    if (!target && parsed.candidate) {
      target = parsed.candidate
      targetType = "candidate"
    }

    if (!target && parsed.candidateId) {
      target = await activeStore.getCandidate(parsed.candidateId) ?? undefined
      targetType = "candidate"
    }

    if (!target) {
      return c.json({ error: "evaluation_target_not_found" }, 404)
    }

    const evaluation = await activeStore.createMemoryEvaluation(evaluateMemoryLike({ target, targetType }))
    return c.json(evaluation, 201)
  })

  api.post("/v1/evals/handoff", async (c) => {
    const body = await c.req.json()
    const parsed = HandoffCompletenessEvaluationRequestSchema.parse(body)
    let handoff = parsed.handoff

    if (!handoff && parsed.handoffId) {
      handoff = await activeStore.getHandoff(parsed.handoffId) ?? undefined
    }

    if (!handoff) {
      return c.json({ error: "evaluation_target_not_found" }, 404)
    }

    const evaluation = await activeStore.createMemoryEvaluation(evaluateHandoffCompleteness(handoff))
    return c.json(evaluation, 201)
  })

  api.post("/v1/events", async (c) => {
    const body = await c.req.json()
    const parsed = CreateMemoryEventSchema.parse(body)
    const event = await activeStore.createEvent(parsed)
    return c.json(event, 201)
  })

  api.post("/v1/memory", async (c) => {
    const body = await c.req.json()
    const parsed = CreateMemoryRecordSchema.parse(body)
    const policyDecision = await persistPolicyCheck({
      action: "memory.write",
      projectId: typeof parsed.scope?.projectId === "string" ? parsed.scope.projectId : undefined,
      namespace: parsed.namespace,
      targetType: "memory",
      targetId: parsed.id,
      memoryType: parsed.memoryType,
      sensitivity: parsed.sensitivity ?? "normal",
      evidenceCount: (parsed.sourceEventIds?.length ?? 0) + (parsed.sourceArtifactIds?.length ?? 0),
      payload: { content: parsed.content, structuredContent: parsed.structuredContent },
    })

    if (policyDecision.decision === "deny") {
      return c.json({ error: "policy_denied", policyDecision }, 403)
    }

    const memory = await activeStore.createMemory(parsed)
    await activeStore.createMemoryEvaluation(evaluateMemoryLike({ target: memory, targetType: "memory" }))
    return c.json(memory, 201)
  })

  api.get("/v1/memory/:id", async (c) => {
    const memory = await activeStore.getMemory(c.req.param("id"))
    if (!memory) {
      return c.json({ error: "memory_not_found" }, 404)
    }
    return c.json(memory)
  })

  api.post("/v1/memory/search", async (c) => {
    const body = await c.req.json()
    const parsed = MemorySearchRequestSchema.parse(body)
    const results = await activeStore.searchMemory(parsed)
    return c.json({ results })
  })

  api.post("/v1/memory/candidates", async (c) => {
    const body = await c.req.json()
    const parsed = CreateMemoryCandidateSchema.parse(body)
    const candidate = await activeStore.createCandidate(parsed)
    return c.json(candidate, 201)
  })

  api.post("/v1/memory/candidates/extract", async (c) => {
    const body = await c.req.json()
    const parsed = ExtractMemoryCandidatesRequestSchema.parse(body)
    const candidateInputs = extractMemoryCandidates(parsed)
    const candidates: MemoryCandidate[] = []

    for (const candidateInput of candidateInputs) {
      candidates.push(await activeStore.createCandidate(candidateInput))
    }

    return c.json({ candidates }, 201)
  })

  api.post("/v1/memory/candidates/search", async (c) => {
    const body = await c.req.json()
    const parsed = MemoryCandidateSearchRequestSchema.parse(body)
    const results = await activeStore.searchCandidates(parsed)
    return c.json({ results })
  })

  api.get("/v1/memory/candidates/:id", async (c) => {
    const candidate = await activeStore.getCandidate(c.req.param("id"))
    if (!candidate) {
      return c.json({ error: "candidate_not_found" }, 404)
    }
    return c.json(candidate)
  })

  api.post("/v1/memory/candidates/:id/promote", async (c) => {
    const body = await c.req.json()
    const parsed = PromoteMemoryCandidateRequestSchema.parse(body)
    const candidate = await activeStore.getCandidate(c.req.param("id"))
    if (!candidate) {
      return c.json({ error: "candidate_not_found" }, 404)
    }

    const policyDecision = await persistPolicyCheck({
      action: "candidate.promote",
      projectId: typeof candidate.scope?.projectId === "string" ? candidate.scope.projectId : undefined,
      namespace: parsed.namespace ?? candidate.namespace,
      targetType: "candidate",
      targetId: candidate.id,
      candidateType: candidate.candidateType,
      memoryType: parsed.memoryType ?? candidate.suggestedMemoryType,
      sensitivity: parsed.sensitivity ?? candidate.sensitivity,
      evidenceCount: candidate.sourceEventIds.length + candidate.sourceArtifactIds.length,
      payload: { content: parsed.content ?? candidate.content, structuredContent: parsed.structuredContent ?? candidate.structuredContent },
    })

    if (policyDecision.decision === "deny") {
      return c.json({ error: "policy_denied", policyDecision }, 403)
    }

    const result = await activeStore.promoteCandidate(c.req.param("id"), parsed)
    if (!result) {
      return c.json({ error: "candidate_not_found" }, 404)
    }
    await activeStore.createMemoryEvaluation(evaluateMemoryLike({ target: result.memory, targetType: "memory" }))
    return c.json(result)
  })

  api.post("/v1/memory/candidates/:id/reject", async (c) => {
    const body = await c.req.json()
    const parsed = RejectMemoryCandidateRequestSchema.parse(body)
    const candidate = await activeStore.rejectCandidate(c.req.param("id"), parsed.reason)
    if (!candidate) {
      return c.json({ error: "candidate_not_found" }, 404)
    }
    return c.json(candidate)
  })

  api.post("/v1/context/plan", async (c) => {
    const body = await c.req.json()
    const parsed = ContextBuildRequestSchema.parse(body)
    const { pack } = buildContextPack(parsed, [])
    return c.json(pack.plan)
  })

  api.post("/v1/context/build", async (c) => {
    const body = await c.req.json()
    const parsed = ContextBuildRequestSchema.parse(body)
    const policyDecision = await persistPolicyCheck({
      action: "context.retrieve",
      projectId: parsed.projectId,
      targetType: "context_pack",
      sensitivity: parsed.retrieval.allowSensitive ? "sensitive" : "normal",
      allowSensitive: parsed.retrieval.allowSensitive,
      purpose: parsed.task,
      payload: { query: parsed.query, include: parsed.include, retrieval: parsed.retrieval },
    })

    if (policyDecision.decision === "deny") {
      return c.json({ error: "policy_denied", policyDecision }, 403)
    }

    const activeMemories = await activeStore.listActiveMemories(parsed.projectId ? { projectId: parsed.projectId } : {})
    const { pack, rankings } = buildContextPack(parsed, activeMemories)

    const auditInput = {
      task: parsed.task,
      strategy: parsed.retrieval.strategy,
      include: parsed.include,
      maxInputTokens: parsed.budget.maxInputTokens,
      parameters: {
        model: parsed.model,
        budget: parsed.budget,
        retrieval: parsed.retrieval,
        planId: pack.plan.id,
        candidateMemoryCount: activeMemories.length,
      },
      ...(parsed.projectId ? { projectId: parsed.projectId } : {}),
      ...(parsed.query ? { query: parsed.query } : {}),
    }

    const auditRequest = await activeStore.createContextRetrievalRequest(auditInput)

    for (const ranking of rankings) {
      await activeStore.createContextRetrievalResult({
        requestId: auditRequest.id,
        memoryId: ranking.memoryId,
        sectionName: ranking.sectionName,
        rank: ranking.rank,
        score: ranking.score,
        reasons: ranking.reasons,
        included: true,
        estimatedTokens: ranking.estimatedTokens,
      })
    }

    pack.retrievalAuditId = auditRequest.id
    return c.json(pack)
  })


  api.post("/v1/handoffs/compile", async (c) => {
    const body = await c.req.json()
    const parsed = HandoffCompileRequestSchema.parse(body)
    const policyDecision = await persistPolicyCheck({
      action: "handoff.export",
      projectId: parsed.projectId,
      targetType: "handoff",
      sensitivity: parsed.retrieval?.allowSensitive ? "sensitive" : "normal",
      allowSensitive: parsed.retrieval?.allowSensitive ?? false,
      purpose: parsed.objective,
      payload: { title: parsed.title, objective: parsed.objective, include: parsed.include, artifactRefs: parsed.artifactRefs },
    })

    if (policyDecision.decision === "deny") {
      return c.json({ error: "policy_denied", policyDecision }, 403)
    }

    const contextRequest = ContextBuildRequestSchema.parse({
      projectId: parsed.projectId,
      task: parsed.task ?? parsed.objective,
      query: parsed.query,
      include: parsed.include,
      model: parsed.model,
      budget: parsed.budget,
      retrieval: parsed.retrieval,
    })

    const activeMemories = await activeStore.listActiveMemories(
      contextRequest.projectId ? { projectId: contextRequest.projectId } : {},
    )
    const { pack, rankings } = buildContextPack(contextRequest, activeMemories)

    const auditRequest = await activeStore.createContextRetrievalRequest({
      task: contextRequest.task,
      strategy: contextRequest.retrieval.strategy,
      include: contextRequest.include,
      maxInputTokens: contextRequest.budget.maxInputTokens,
      parameters: {
        model: contextRequest.model,
        budget: contextRequest.budget,
        retrieval: contextRequest.retrieval,
        planId: pack.plan.id,
        candidateMemoryCount: activeMemories.length,
        compileHandoff: true,
      },
      ...(contextRequest.projectId ? { projectId: contextRequest.projectId } : {}),
      ...(contextRequest.query ? { query: contextRequest.query } : {}),
    })

    for (const ranking of rankings) {
      await activeStore.createContextRetrievalResult({
        requestId: auditRequest.id,
        memoryId: ranking.memoryId,
        sectionName: ranking.sectionName,
        rank: ranking.rank,
        score: ranking.score,
        reasons: ranking.reasons,
        included: true,
        estimatedTokens: ranking.estimatedTokens,
      })
    }

    pack.retrievalAuditId = auditRequest.id
    const compiled = compileHandoff(parsed, pack)
    const handoff = await activeStore.createHandoff(compiled.handoffInput)
    await activeStore.createMemoryEvaluation(evaluateHandoffCompleteness(handoff))

    return c.json(
      {
        compileId: compiled.compileId,
        handoff,
        contextPack: pack,
        sourceMemoryIds: compiled.sourceMemoryIds,
        markdown: handoff.markdown,
        json: { ...compiled.json, handoffId: handoff.id },
        createdAt: compiled.createdAt,
      },
      201,
    )
  })
  api.post("/v1/handoffs", async (c) => {
    const body = await c.req.json()
    const parsed = HandoffCreateRequestSchema.parse(body)
    const policyDecision = await persistPolicyCheck({
      action: "handoff.export",
      projectId: parsed.projectId,
      targetType: "handoff",
      sensitivity: "normal",
      purpose: parsed.objective,
      payload: { title: parsed.title, objective: parsed.objective, sourceMemoryIds: parsed.sourceMemoryIds },
    })

    if (policyDecision.decision === "deny") {
      return c.json({ error: "policy_denied", policyDecision }, 403)
    }

    const pack = await activeStore.createHandoff(parsed)
    await activeStore.createMemoryEvaluation(evaluateHandoffCompleteness(pack))
    return c.json(pack, 201)
  })

  api.get("/v1/handoffs/:id", async (c) => {
    const handoff = await activeStore.getHandoff(c.req.param("id"))
    if (!handoff) {
      return c.json({ error: "handoff_not_found" }, 404)
    }
    return c.json(handoff)
  })

  return api
}

export default {
  port: config.apiPort,
  fetch: app.fetch,
}

console.log(`continuum-memory-api listening on http://localhost:${config.apiPort} with ${store.kind} store`)
