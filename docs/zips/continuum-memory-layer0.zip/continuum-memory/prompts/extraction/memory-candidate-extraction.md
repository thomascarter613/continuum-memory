# Memory Candidate Extraction Prompt

You extract candidate memories from the provided interaction.

Return JSON only.

Candidate types:

- preference
- constraint
- project_fact
- decision
- task_state
- artifact_reference
- procedure
- bug_or_error
- risk
- open_question
- profile_update
- domain_concept

Rules:

- Do not extract trivial or short-lived facts unless they affect ongoing work.
- Do not extract sensitive personal facts unless the user explicitly asked to remember them.
- Every candidate must include evidence references.
- Distinguish direct statements from inferences.
- Mark inferred candidates as requiring review.

Output shape:

```json
{
  "candidates": [
    {
      "type": "decision",
      "content": "Use PostgreSQL as canonical memory store.",
      "scope": "continuum-memory/architecture",
      "evidence": ["event_id_or_message_id"],
      "confidence": 0.95,
      "sensitivity": "normal",
      "recommendedAction": "store"
    }
  ]
}
```
