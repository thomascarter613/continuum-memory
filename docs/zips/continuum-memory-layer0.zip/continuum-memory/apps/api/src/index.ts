import { randomUUID } from "node:crypto"
import { Hono } from "hono"
import {
  ContextBuildRequestSchema,
  CreateMemoryEventSchema,
  CreateMemoryRecordSchema,
  HandoffCreateRequestSchema,
  MemorySearchRequestSchema,
  type ContextPack,
  type HandoffPack,
  type MemoryEvent,
  type MemoryRecord,
} from "@continuum/domain"

const app = new Hono()

const events = new Map<string, MemoryEvent>()
const memories = new Map<string, MemoryRecord>()
const handoffs = new Map<string, HandoffPack>()

function now() {
  return new Date().toISOString()
}

function estimateTokens(text: string) {
  return Math.ceil(text.length / 4)
}

function renderHandoffMarkdown(input: {
  title: string
  objective: string
  currentState: string
  acceptedDecisions: string[]
  openQuestions: string[]
  nextActions: string[]
  artifactRefs: string[]
}) {
  const list = (items: string[]) => (items.length ? items.map((item) => `- ${item}`).join("\n") : "- None")

  return `# ${input.title}

## Objective

${input.objective}

## Current State

${input.currentState || "No current state supplied."}

## Accepted Decisions

${list(input.acceptedDecisions)}

## Open Questions

${list(input.openQuestions)}

## Next Actions

${list(input.nextActions)}

## Artifact References

${list(input.artifactRefs)}
`
}

app.get("/healthz", (c) => {
  return c.json({ ok: true, service: "continuum-memory-api" })
})

app.post("/v1/events", async (c) => {
  const body = await c.req.json()
  const parsed = CreateMemoryEventSchema.parse(body)
  const event: MemoryEvent = {
    ...parsed,
    id: parsed.id ?? randomUUID(),
    occurredAt: parsed.occurredAt ?? now(),
    payload: parsed.payload ?? {},
  }
  events.set(event.id, event)
  return c.json(event, 201)
})

app.post("/v1/memory", async (c) => {
  const body = await c.req.json()
  const parsed = CreateMemoryRecordSchema.parse(body)
  const timestamp = now()
  const memory: MemoryRecord = {
    ...parsed,
    id: parsed.id ?? randomUUID(),
    sourceEventIds: parsed.sourceEventIds ?? [],
    sourceArtifactIds: parsed.sourceArtifactIds ?? [],
    scope: parsed.scope ?? {},
    confidence: parsed.confidence ?? 0.5,
    sensitivity: parsed.sensitivity ?? "normal",
    status: parsed.status ?? "active",
    createdAt: parsed.createdAt ?? timestamp,
    updatedAt: parsed.updatedAt ?? timestamp,
  }
  memories.set(memory.id, memory)
  return c.json(memory, 201)
})

app.get("/v1/memory/:id", (c) => {
  const memory = memories.get(c.req.param("id"))
  if (!memory) {
    return c.json({ error: "memory_not_found" }, 404)
  }
  return c.json(memory)
})

app.post("/v1/memory/search", async (c) => {
  const body = await c.req.json()
  const parsed = MemorySearchRequestSchema.parse(body)
  const query = parsed.query?.toLowerCase()

  const results = [...memories.values()]
    .filter((memory) => parsed.includeSuperseded || memory.status !== "superseded")
    .filter((memory) => !parsed.namespace || memory.namespace === parsed.namespace)
    .filter((memory) => !parsed.memoryTypes || parsed.memoryTypes.includes(memory.memoryType))
    .filter((memory) => !query || memory.content.toLowerCase().includes(query))
    .slice(0, parsed.limit)

  return c.json({ results })
})

app.post("/v1/context/build", async (c) => {
  const body = await c.req.json()
  const parsed = ContextBuildRequestSchema.parse(body)
  const activeMemories = [...memories.values()].filter((memory) => memory.status === "active")

  const sections = parsed.include.map((sectionName) => {
    const sectionMemories = activeMemories.filter((memory) => {
      if (sectionName === "decisions") return memory.memoryType === "decision"
      if (sectionName === "procedures") return memory.memoryType === "procedural"
      if (sectionName === "recent_episodes") return memory.memoryType === "episodic"
      if (sectionName === "user_preferences") return memory.namespace.includes("user")
      if (sectionName === "project_state") return memory.namespace.includes("project")
      return true
    })

    const content = sectionMemories.map((memory) => `- ${memory.content}`).join("\n")
    return {
      name: sectionName,
      purpose: `Context section for ${sectionName}`,
      memories: sectionMemories,
      content,
    }
  })

  const assembled = sections.map((section) => `## ${section.name}\n${section.content}`).join("\n\n")
  const contextPack: ContextPack = {
    id: randomUUID(),
    projectId: parsed.projectId,
    task: parsed.task,
    sections,
    tokenBudget: {
      maxInputTokens: parsed.budget.maxInputTokens,
      estimatedUsedTokens: estimateTokens(assembled),
    },
    createdAt: now(),
  }

  return c.json(contextPack)
})

app.post("/v1/handoffs", async (c) => {
  const body = await c.req.json()
  const parsed = HandoffCreateRequestSchema.parse(body)
  const pack: HandoffPack = {
    id: randomUUID(),
    projectId: parsed.projectId,
    title: parsed.title,
    objective: parsed.objective,
    markdown: renderHandoffMarkdown(parsed),
    payload: parsed,
    createdAt: now(),
  }

  handoffs.set(pack.id, pack)
  return c.json(pack, 201)
})

app.get("/v1/handoffs/:id", (c) => {
  const handoff = handoffs.get(c.req.param("id"))
  if (!handoff) {
    return c.json({ error: "handoff_not_found" }, 404)
  }
  return c.json(handoff)
})

const port = Number(process.env.CONTINUUM_API_PORT ?? 3030)

export default {
  port,
  fetch: app.fetch,
}

console.log(`continuum-memory-api listening on http://localhost:${port}`)
