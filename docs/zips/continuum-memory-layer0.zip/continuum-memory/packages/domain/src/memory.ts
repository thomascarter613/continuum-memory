import { z } from "zod"

export const MemoryTypeSchema = z.enum([
  "working",
  "episodic",
  "semantic",
  "procedural",
  "decision",
  "artifact",
  "handoff",
  "profile",
])

export type MemoryType = z.infer<typeof MemoryTypeSchema>

export const SensitivitySchema = z.enum(["public", "normal", "private", "sensitive", "secret"])
export type Sensitivity = z.infer<typeof SensitivitySchema>

export const MemoryStatusSchema = z.enum([
  "candidate",
  "active",
  "rejected",
  "superseded",
  "deprecated",
  "forgotten",
  "archived",
])
export type MemoryStatus = z.infer<typeof MemoryStatusSchema>

export const MemoryEventSchema = z.object({
  id: z.string().uuid(),
  eventType: z.string().min(1),
  actorType: z.string().min(1),
  actorId: z.string().optional(),
  subjectType: z.string().optional(),
  subjectId: z.string().optional(),
  projectId: z.string().optional(),
  conversationId: z.string().optional(),
  sessionId: z.string().optional(),
  runId: z.string().optional(),
  payload: z.record(z.string(), z.unknown()).default({}),
  occurredAt: z.string().datetime(),
  causationId: z.string().uuid().optional(),
  correlationId: z.string().uuid().optional(),
})

export type MemoryEvent = z.infer<typeof MemoryEventSchema>

export const CreateMemoryEventSchema = MemoryEventSchema.omit({ id: true, occurredAt: true }).extend({
  id: z.string().uuid().optional(),
  occurredAt: z.string().datetime().optional(),
})

export type CreateMemoryEvent = z.infer<typeof CreateMemoryEventSchema>

export const MemoryRecordSchema = z.object({
  id: z.string().uuid(),
  memoryType: MemoryTypeSchema,
  namespace: z.string().min(1),
  scope: z.record(z.string(), z.unknown()).default({}),
  content: z.string().min(1),
  structuredContent: z.record(z.string(), z.unknown()).optional(),
  sourceEventIds: z.array(z.string().uuid()).default([]),
  sourceArtifactIds: z.array(z.string().uuid()).default([]),
  confidence: z.number().min(0).max(1).default(0.5),
  sensitivity: SensitivitySchema.default("normal"),
  status: MemoryStatusSchema.default("active"),
  validFrom: z.string().datetime().optional(),
  validTo: z.string().datetime().optional(),
  supersedes: z.string().uuid().optional(),
  supersededBy: z.string().uuid().optional(),
  createdAt: z.string().datetime(),
  updatedAt: z.string().datetime(),
})

export type MemoryRecord = z.infer<typeof MemoryRecordSchema>

export const CreateMemoryRecordSchema = MemoryRecordSchema.omit({
  id: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  id: z.string().uuid().optional(),
  createdAt: z.string().datetime().optional(),
  updatedAt: z.string().datetime().optional(),
})

export type CreateMemoryRecord = z.infer<typeof CreateMemoryRecordSchema>

export const MemorySearchRequestSchema = z.object({
  query: z.string().optional(),
  namespace: z.string().optional(),
  memoryTypes: z.array(MemoryTypeSchema).optional(),
  projectId: z.string().optional(),
  includeSuperseded: z.boolean().default(false),
  limit: z.number().int().positive().max(100).default(20),
})

export type MemorySearchRequest = z.infer<typeof MemorySearchRequestSchema>
