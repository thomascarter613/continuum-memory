import { z } from "zod"

export const HandoffCreateRequestSchema = z.object({
  projectId: z.string().optional(),
  title: z.string().min(1).default("Continuum Handoff"),
  objective: z.string().min(1),
  currentState: z.string().default(""),
  acceptedDecisions: z.array(z.string()).default([]),
  openQuestions: z.array(z.string()).default([]),
  nextActions: z.array(z.string()).default([]),
  artifactRefs: z.array(z.string()).default([]),
})

export type HandoffCreateRequest = z.infer<typeof HandoffCreateRequestSchema>

export const HandoffPackSchema = z.object({
  id: z.string().uuid(),
  projectId: z.string().optional(),
  title: z.string(),
  objective: z.string(),
  markdown: z.string(),
  payload: HandoffCreateRequestSchema,
  createdAt: z.string().datetime(),
})

export type HandoffPack = z.infer<typeof HandoffPackSchema>
