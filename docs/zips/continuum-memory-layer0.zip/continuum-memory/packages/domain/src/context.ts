import { z } from "zod"
import { MemoryRecordSchema } from "./memory"

export const ContextSectionSchema = z.object({
  name: z.string().min(1),
  purpose: z.string().optional(),
  memories: z.array(MemoryRecordSchema).default([]),
  content: z.string().default(""),
})

export type ContextSection = z.infer<typeof ContextSectionSchema>

export const ContextBuildRequestSchema = z.object({
  userId: z.string().optional(),
  projectId: z.string().optional(),
  task: z.string().min(1),
  model: z
    .object({
      provider: z.string().default("unknown"),
      modelName: z.string().optional(),
      contextWindow: z.number().int().positive().optional(),
    })
    .default({ provider: "unknown" }),
  budget: z
    .object({
      maxInputTokens: z.number().int().positive().default(12000),
    })
    .default({ maxInputTokens: 12000 }),
  include: z.array(z.string()).default([
    "project_state",
    "user_preferences",
    "decisions",
    "procedures",
    "recent_episodes",
    "open_tasks",
  ]),
})

export type ContextBuildRequest = z.infer<typeof ContextBuildRequestSchema>

export const ContextPackSchema = z.object({
  id: z.string().uuid(),
  projectId: z.string().optional(),
  task: z.string(),
  sections: z.array(ContextSectionSchema),
  tokenBudget: z.object({
    maxInputTokens: z.number().int().positive(),
    estimatedUsedTokens: z.number().int().nonnegative(),
  }),
  createdAt: z.string().datetime(),
})

export type ContextPack = z.infer<typeof ContextPackSchema>
