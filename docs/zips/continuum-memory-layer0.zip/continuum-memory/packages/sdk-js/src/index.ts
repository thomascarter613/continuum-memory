import type {
  ContextBuildRequest,
  CreateMemoryEvent,
  CreateMemoryRecord,
  HandoffCreateRequest,
  MemorySearchRequest,
} from "@continuum/domain"

export class ContinuumClient {
  constructor(private readonly baseUrl = "http://localhost:3030") {}

  async health() {
    return this.get("/healthz")
  }

  async createEvent(input: CreateMemoryEvent) {
    return this.post("/v1/events", input)
  }

  async createMemory(input: CreateMemoryRecord) {
    return this.post("/v1/memory", input)
  }

  async searchMemory(input: MemorySearchRequest) {
    return this.post("/v1/memory/search", input)
  }

  async buildContext(input: ContextBuildRequest) {
    return this.post("/v1/context/build", input)
  }

  async createHandoff(input: HandoffCreateRequest) {
    return this.post("/v1/handoffs", input)
  }

  private async get(path: string) {
    const response = await fetch(`${this.baseUrl}${path}`)
    if (!response.ok) throw new Error(`Continuum GET ${path} failed: ${response.status}`)
    return response.json()
  }

  private async post(path: string, body: unknown) {
    const response = await fetch(`${this.baseUrl}${path}`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body),
    })
    if (!response.ok) {
      const text = await response.text()
      throw new Error(`Continuum POST ${path} failed: ${response.status} ${text}`)
    }
    return response.json()
  }
}
