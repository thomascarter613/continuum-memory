# Continuum Memory

Continuum Memory is a model-agnostic persistent memory and context control plane for software-development agents and LLM-assisted work.

It is designed around this rule:

> Chats are disposable. Memory is durable. Context is assembled. Handoffs are explicit artifacts.

This repository is the reusable memory system itself. Product/application monorepos should not embed this whole system. Instead, product repos should include a thin `.memory/` adapter, `AGENTS.md`, ADRs, work packets, current-state docs, and handoff files.

## Layer 0 status

This scaffold creates the foundation:

- Bun workspace
- TypeScript packages
- Hono API shell
- shared domain schemas
- JavaScript SDK shell
- CLI shell
- memory taxonomy docs
- ADRs
- work planning docs
- OPA/Rego policy stubs
- prompt templates
- Docker Compose for local dependencies
- project-adapter template for other monorepos

The API currently uses an in-memory store so the first run is simple. PostgreSQL persistence, pgvector retrieval, Qdrant indexing, and handoff compilation are planned next layers.

## Quickstart

```bash
cp .env.example .env
bun install
bun run check
bun run dev
```

In another terminal:

```bash
curl http://localhost:3030/healthz
```

Expected response:

```json
{"ok":true,"service":"continuum-memory-api"}
```

## Recommended workspace layout

```txt
Workspace/
├── continuum-memory/       # this reusable memory system
├── your-product-monorepo/  # product repo using a thin .memory adapter
└── .continuum-data/        # local runtime data, not committed
```

## Apply the project adapter to another repo

From this repository:

```bash
./scripts/create-project-adapter.sh ../your-product-monorepo
```

This copies the template files that let Continuum understand a software project.

## Main concepts

- **Working memory**: current run/session/task state.
- **Episodic memory**: what happened, when, and with what evidence.
- **Semantic memory**: durable facts, preferences, project state, and stable knowledge.
- **Procedural memory**: reusable workflows, runbooks, prompts, and executable skills.
- **Decision memory**: ADR-like decision records with rationale and alternatives.
- **Artifact memory**: files, generated outputs, logs, diagrams, and external documents.
- **Handoff memory**: portable state packages for resuming work in new chats or models.

## Development commands

```bash
bun run format
bun run lint
bun run typecheck
bun run test
bun run check
bun run dev
```

## Initial API endpoints

```txt
GET  /healthz
POST /v1/events
POST /v1/memory
GET  /v1/memory/:id
POST /v1/memory/search
POST /v1/context/build
POST /v1/handoffs
GET  /v1/handoffs/:id
```
