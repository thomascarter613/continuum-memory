package continuum.memory.write

# Layer 0 policy stub.
# Future: enforce consent, sensitivity, namespace, tenant, and evidence requirements.

default allow := false

allow if {
  input.memory.content != ""
  count(input.memory.sourceEventIds) > 0
  input.memory.sensitivity != "secret"
}

review_required if {
  input.memory.sensitivity == "sensitive"
}
