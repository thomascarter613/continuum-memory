# Roadmap

## Layer 0: Foundation Scaffold

- Repository structure
- Domain schemas
- API shell
- SDK shell
- CLI shell
- Docs, ADRs, policies, prompts
- Project adapter template

## Layer 1: Durable Store

- PostgreSQL connection
- Migration runner
- Event repository
- Memory repository
- Handoff repository
- Tests

## Layer 2: Memory Ingestion

- Candidate extraction prompt runner
- Memory classifier
- Policy check
- Evidence enforcement
- Candidate review workflow

## Layer 3: Context Builder

- Hybrid retrieval
- Context planning
- Token budgeting
- Context pack rendering
- Project profile import

## Layer 4: Handoff Compiler

- Handoff from current project state
- Handoff from recent episodes
- Markdown/JSON export
- Git-safe handoff output

## Layer 5: Governance and Evaluation

- Policy engine integration
- Memory quality evals
- Stale-memory detection
- Supersession engine
- Privacy and retention tests

## Layer 6: Developer Experience

- Web admin UI
- IDE integrations
- Chat client export formats
- GitHub issue/PR integrations
