# Current State

## Active Objective

Create Layer 0 of Continuum Memory: a model-agnostic persistent memory and context control plane for software-development assistance.

## Current Phase

Foundation scaffold.

## Accepted Decisions

- Build Continuum Memory as a separate reusable monorepo.
- Use repo-local `.memory/` adapters in product monorepos.
- Use PostgreSQL as canonical memory store.
- Treat vector stores as indexes.
- Make handoff packs first-class artifacts.
- Start with a simple Bun + TypeScript + Hono API shell.

## Next Recommended Layer

Layer 1 should replace the in-memory API store with PostgreSQL persistence and add migrations, repository interfaces, and tests.
